import { jsxs, jsx } from "react/jsx-runtime";
import { A as Authenticated } from "./AuthenticatedLayout-B0RmSo8o.js";
import DeleteUserForm from "./DeleteUserForm-CNmi8dfw.js";
import UpdatePasswordForm from "./UpdatePasswordForm-CdtTmumx.js";
import UpdateProfileInformation from "./UpdateProfileInformationForm-BAEBZFPa.js";
import { Head } from "@inertiajs/react";
import "react";
import "./NavLink-DTY072R5.js";
import "framer-motion";
import "./Harmbuger-DjbFdboI.js";
import "./DangerButton-1tnFs2BV.js";
import "./InputError-PdXTNpsB.js";
import "./InputLabel-CaoVq05r.js";
import "./Modal-BunpyNFw.js";
import "@headlessui/react";
import "./TextInput-BcQtEsKK.js";
import "./PrimaryButton-namq1TfZ.js";
import "@heroicons/react/24/outline";
function Edit({ auth, mustVerifyEmail, status }) {
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Profile" }),
        /* @__PURE__ */ jsx("div", { className: "py-12", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6", children: [
          /* @__PURE__ */ jsx("div", { className: "p-4 sm:p-8 bg-white dark:bg-grey-800 shadow sm:rounded-lg", children: /* @__PURE__ */ jsx(
            UpdateProfileInformation,
            {
              mustVerifyEmail,
              status,
              className: "max-w-xl"
            }
          ) }),
          /* @__PURE__ */ jsx("div", { className: "p-4 sm:p-8 bg-white dark:bg-grey-800 shadow sm:rounded-lg", children: /* @__PURE__ */ jsx(UpdatePasswordForm, { className: "max-w-xl" }) }),
          /* @__PURE__ */ jsx("div", { className: "p-4 sm:p-8 bg-white dark:bg-grey-800 shadow sm:rounded-lg", children: /* @__PURE__ */ jsx(DeleteUserForm, { className: "max-w-xl" }) })
        ] }) })
      ]
    }
  );
}
export {
  Edit as default
};
