import { jsxs, jsx } from "react/jsx-runtime";
import { M as Messaging } from "./Messaging-x51nvob9.js";
import { P as PrimaryButton } from "./PrimaryButton-namq1TfZ.js";
import { A as AdminLayout } from "./AdminLayout-BLojdTCi.js";
import { useForm } from "@inertiajs/react";
import { useState, useEffect } from "react";
import "react-dom";
import "framer-motion";
import "./NavLink-DTY072R5.js";
import "@heroicons/react/24/solid";
import "@heroicons/react/24/outline";
function View({ auth, category = {} }) {
  const { data, setData, reset, patch, errors } = useForm({
    name: "",
    description: ""
  });
  const [messaging, setMessaging] = useState({
    type: "",
    message: "",
    show: false
  });
  const submit = (e) => {
    e.preventDefault();
    patch(route("categories.update", [category.id]), {
      preserveScroll: true,
      onSuccess: () => {
        setMessaging({
          type: "success",
          message: "Category updated successfully.",
          show: true
        });
      }
    });
  };
  useEffect(() => {
    setData(category);
  }, [category]);
  const onClose = () => {
    setMessaging({ ...messaging, show: false });
  };
  return /* @__PURE__ */ jsxs(AdminLayout, { user: auth.user, children: [
    /* @__PURE__ */ jsx(
      Messaging,
      {
        onClose,
        message: messaging.message,
        mtype: messaging.type,
        show: messaging.show
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "rounded-sm bg-white py-6 px-7.5 shadow-default dark:bg-boxdark", children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-title-md font-bold text-black dark:text-white capitalize", children: [
        category.name,
        " Category"
      ] }),
      /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "max-w-xl mt-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
          /* @__PURE__ */ jsx("label", { htmlFor: "name", children: "Category Name" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              name: "name",
              id: "name",
              className: "form-input",
              value: data.name,
              onChange: (e) => setData("name", e.target.value)
            }
          ),
          /* @__PURE__ */ jsx("p", { className: "text-red-500", children: errors.name })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
          /* @__PURE__ */ jsx("label", { htmlFor: "description", children: "Category Description" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              name: "description",
              id: "description",
              className: "form-input",
              value: data.description,
              onChange: (e) => setData("description", e.target.value)
            }
          ),
          /* @__PURE__ */ jsx("p", { className: "text-red-500", children: errors.description })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsx(PrimaryButton, { type: "submit", children: "Update" }) })
      ] })
    ] })
  ] });
}
export {
  View as default
};
