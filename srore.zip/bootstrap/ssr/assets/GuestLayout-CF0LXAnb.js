import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { A as ApplicationLogo, N as NavLink } from "./NavLink-DTY072R5.js";
import { T as ThemeSwitcher, H as Harmbuger } from "./Harmbuger-DjbFdboI.js";
function Guest({
  children,
  auth = true
}) {
  const [showingNavigationDropdown, setShowingNavigationDropdown] = useState(false);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: `relative min-h-screen ${auth && "flex flex-col justify-between pt-6 sm:pt-0"}`,
      children: [
        /* @__PURE__ */ jsx("nav", { className: "bg-white shadow-lg dark:bg-grey-950 py-3.5 px-6  w-full lg:shadow-none fixed z-50", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-1 sm:gap-6 lg:flex-row flex-col", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center lg:w-auto w-full", children: [
            /* @__PURE__ */ jsx(ThemeSwitcher, { className: "lg:hidden" }),
            /* @__PURE__ */ jsx("a", { href: "#", className: "block", children: /* @__PURE__ */ jsx(ApplicationLogo, {}) }),
            /* @__PURE__ */ jsxs(
              "button",
              {
                id: "navbar-toggle",
                type: "button",
                className: "inline-flex items-center mr-3 text-sm rounded-lg lg:hidden focus:outline-none ",
                "aria-controls": "navbar-default",
                "aria-expanded": "false",
                onClick: () => setShowingNavigationDropdown(
                  !showingNavigationDropdown
                ),
                children: [
                  /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Open main menu" }),
                  /* @__PURE__ */ jsx(Harmbuger, { checked: showingNavigationDropdown })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs(
            "div",
            {
              id: "mobile-navbar",
              className: `${!showingNavigationDropdown && "hidden"} lg:flex flex-row w-full flex-1`,
              style: { zIndex: 1e3 },
              children: [
                /* @__PURE__ */ jsxs("ul", { className: "text-center flex lg:flex-row flex-col lg:gap-2 xl:gap-4 gap-2 items-start lg:ml-auto", children: [
                  /* @__PURE__ */ jsx(
                    NavLink,
                    {
                      href: route("home"),
                      active: route().current("home"),
                      children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Home" })
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    NavLink,
                    {
                      href: route("shop"),
                      active: route().current("shop"),
                      children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Shop" })
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    NavLink,
                    {
                      href: route("login"),
                      active: route().current("login"),
                      children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Login" })
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    NavLink,
                    {
                      href: route("register"),
                      active: route().current("register"),
                      children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Register" })
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx("div", { className: "text-center lg:flex  items-center gap-1  sm:gap-4 lg:ml-auto", children: /* @__PURE__ */ jsx("div", { className: " flex items-center lg:justify-start justify-center gap-1 sm:gap-2", children: /* @__PURE__ */ jsx(ThemeSwitcher, { className: "hidden lg:inline-flex" }) }) })
              ]
            }
          )
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "pt-[68px] bg-grey-200 text-grey-900 dark:text-grey-100 dark:bg-grey-900 flex-grow flex flex-col", children: /* @__PURE__ */ jsx(
          "div",
          {
            className: `w-full p-8 flex-grow ${auth && "flex flex-col justify-center items-center"}`,
            children: auth ? /* @__PURE__ */ jsx("div", { className: "w-full", children: /* @__PURE__ */ jsx("div", { className: "mx-auto max-w-2xl px-6 lg:px-8 rounded-2xl bg-white dark:bg-grey-800 shadow-xl", children }) }) : /* @__PURE__ */ jsxs("div", { children: [
              children,
              " "
            ] })
          }
        ) })
      ]
    }
  );
}
export {
  Guest as G
};
