import { jsxs, jsx } from "react/jsx-runtime";
import { M as Messaging } from "./Messaging-x51nvob9.js";
import { A as Authenticated } from "./AuthenticatedLayout-B0RmSo8o.js";
import { Link, router } from "@inertiajs/react";
import { useState } from "react";
import "react-dom";
import "framer-motion";
import "./NavLink-DTY072R5.js";
import "./Harmbuger-DjbFdboI.js";
function Cart({
  auth,
  cart,
  products,
  total,
  deliveryCharge = 0
}) {
  const [messaging, setMessaging] = useState({
    type: "",
    message: "",
    show: false
  });
  const handleReduce = (product) => (event) => {
    const data = {
      product_id: product.id,
      quantity: product.pivot.quantity - 1
    };
    router.post(route("cart.update"), data, {
      preserveScroll: true,
      onSuccess: () => {
        setMessaging({
          type: "success",
          message: "Cart updated successfully",
          show: true
        });
      },
      onError: () => {
        setMessaging({
          type: "error",
          message: "Cart update failed",
          show: true
        });
      }
    });
  };
  const handleIncrease = (product) => (event) => {
    const data = {
      product_id: product.id,
      quantity: product.pivot.quantity + 1
    };
    router.post(route("cart.update"), data, {
      preserveScroll: true,
      onSuccess: () => {
        setMessaging({
          type: "success",
          message: "Cart updated successfully",
          show: true
        });
      },
      onError: () => {
        setMessaging({
          type: "error",
          message: "Cart update failed",
          show: true
        });
      }
    });
  };
  const onClose = () => {
    setMessaging({ ...messaging, show: false });
  };
  return /* @__PURE__ */ jsxs(Authenticated, { user: auth.user, children: [
    /* @__PURE__ */ jsx(
      Messaging,
      {
        message: messaging.message,
        mtype: messaging.type,
        show: messaging.show,
        onClose
      }
    ),
    /* @__PURE__ */ jsx("section", { className: "py-24 relative", children: /* @__PURE__ */ jsxs("div", { className: "w-full max-w-7xl px-4 md:px-5 lg-6 mx-auto", children: [
      /* @__PURE__ */ jsx("h2", { className: "title font-manrope font-bold text-4xl leading-10 mb-8 text-center", children: "Shopping Cart" }),
      /* @__PURE__ */ jsxs("div", { className: "hidden lg:grid grid-cols-2 py-6", children: [
        /* @__PURE__ */ jsx("div", { className: "font-normal text-xl leading-8", children: "Product" }),
        /* @__PURE__ */ jsxs("p", { className: "font-normal text-xl leading-8 flex items-center w-full mx-auto justify-between", children: [
          /* @__PURE__ */ jsx("div", { className: "basis-1/2 flex justify-end", children: /* @__PURE__ */ jsx("span", { className: "w-full max-w-[260px] text-center ", children: "Quantity" }) }),
          /* @__PURE__ */ jsx("div", { className: "basis-1/2 flex justify-end", children: /* @__PURE__ */ jsx("span", { className: "w-full max-w-[200px] text-center", children: "Total" }) })
        ] })
      ] }),
      products.map((product, index) => {
        var _a, _b;
        return /* @__PURE__ */ jsxs(
          "div",
          {
            className: "grid grid-cols-1 lg:grid-cols-2 min-[550px]:gap-6 border-t border-grey-800 dark:border-grey-200 py-6",
            children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center flex-col min-[550px]:flex-row gap-3 min-[550px]:gap-6 w-full max-xl:justify-center max-xl:max-w-xl max-xl:mx-auto", children: [
                /* @__PURE__ */ jsx("div", { className: "img-box", children: /* @__PURE__ */ jsx(
                  "img",
                  {
                    src: `/storage/${product.image}`,
                    alt: product.name,
                    className: "xl:w-[140px] rounded-xl"
                  }
                ) }),
                /* @__PURE__ */ jsxs("div", { className: "pro-data w-full max-w-sm", children: [
                  /* @__PURE__ */ jsx("h5", { className: "font-semibold text-xl leading-8 max-[550px]:text-center", children: product.name }),
                  /* @__PURE__ */ jsxs("p", { className: "font-normal text-lg leading-8 my-2 min-[550px]:my-3 max-[550px]:text-center", children: [
                    /* @__PURE__ */ jsx("span", { className: "capitalize", children: (_a = product.category) == null ? void 0 : _a.name }),
                    " ",
                    /* @__PURE__ */ jsx("span", { className: "text-indigo-600", children: " / " }),
                    " ",
                    /* @__PURE__ */ jsx("span", { className: "capitalize", children: (_b = product.product_type) == null ? void 0 : _b.name })
                  ] }),
                  /* @__PURE__ */ jsxs("h6", { className: "font-medium text-lg leading-8 text-indigo-600 max-[550px]:text-center", children: [
                    "£ ",
                    product.price
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center flex-col min-[550px]:flex-row w-full max-xl:max-w-xl max-xl:mx-auto gap-2", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center w-full mx-auto justify-center", children: [
                  /* @__PURE__ */ jsx(
                    "button",
                    {
                      onClick: handleReduce(product),
                      type: "button",
                      className: "group rounded-l-full px-6 py-[18px] border border-indigo-600 flex items-center justify-center shadow-sm shadow-transparent transition-all duration-500",
                      children: /* @__PURE__ */ jsx(
                        "svg",
                        {
                          className: "stroke-grey-800 dark:stroke-grey-200",
                          xmlns: "http://www.w3.org/2000/svg",
                          width: "22",
                          height: "22",
                          viewBox: "0 0 22 22",
                          fill: "none",
                          children: /* @__PURE__ */ jsx(
                            "path",
                            {
                              d: "M16.5 11H5.5",
                              stroke: "",
                              strokeWidth: "1.6",
                              strokeLinecap: "round"
                            }
                          )
                        }
                      )
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "text",
                      className: "border-y border-indigo-600 outline-none focus:outline-none focus:ring-0 focus:border-indigo-600 font-semibold text-lg w-full max-w-[118px] min-w-[80px] py-[15px] text-center bg-transparent",
                      value: product.pivot.quantity,
                      readOnly: true
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "button",
                    {
                      onClick: handleIncrease(product),
                      className: "group rounded-r-full px-6 py-[18px] border border-indigo-600 flex items-center justify-center hover:shadow-lg",
                      children: /* @__PURE__ */ jsx(
                        "svg",
                        {
                          className: "stroke-grey-800 dark:stroke-grey-200",
                          xmlns: "http://www.w3.org/2000/svg",
                          width: "22",
                          height: "22",
                          viewBox: "0 0 22 22",
                          fill: "none",
                          children: /* @__PURE__ */ jsx(
                            "path",
                            {
                              d: "M11 5.5V16.5M16.5 11H5.5",
                              stroke: "",
                              strokeWidth: "1.6",
                              strokeLinecap: "round"
                            }
                          )
                        }
                      )
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("h6", { className: "text-indigo-600 font-manrope font-bold text-2xl leading-9 w-full max-w-[176px] text-center", children: [
                  "£ ",
                  product.price * product.pivot.quantity
                ] })
              ] })
            ]
          },
          index
        );
      }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-xl p-6 w-full mb-8 max-lg:max-w-xl max-lg:mx-auto", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between w-full mb-6", children: [
          /* @__PURE__ */ jsx("p", { className: "font-normal text-xl leading-8", children: "Sub Total" }),
          /* @__PURE__ */ jsxs("h6", { className: "font-semibold text-xl leading-8", children: [
            "£ ",
            total
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between w-full pb-6 border-b border-grey-800 dark:border-grey-200", children: [
          /* @__PURE__ */ jsx("p", { className: "font-normal text-xl leading-8", children: "Delivery Charge" }),
          /* @__PURE__ */ jsxs("h6", { className: "font-semibold text-xl leading-8", children: [
            "£ ",
            deliveryCharge
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between w-full py-6", children: [
          /* @__PURE__ */ jsx("p", { className: "font-manrope font-medium text-2xl leading-9 text-grey-900", children: "Total" }),
          /* @__PURE__ */ jsxs("h6", { className: "font-manrope font-medium text-2xl leading-9 text-indigo-500", children: [
            "£ ",
            total + deliveryCharge
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center flex-col sm:flex-row justify-center gap-3 mt-8", children: [
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("shop"),
            className: "rounded-full py-4 w-full max-w-[280px]  flex items-center bg-indigo-50 justify-center transition-all duration-500 hover:bg-indigo-100",
            children: [
              /* @__PURE__ */ jsx("span", { className: "px-2 font-semibold text-lg leading-8 text-indigo-600", children: "Contine Shopping" }),
              /* @__PURE__ */ jsx(
                "svg",
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "22",
                  height: "22",
                  viewBox: "0 0 22 22",
                  fill: "none",
                  children: /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M8.25324 5.49609L13.7535 10.9963L8.25 16.4998",
                      stroke: "#4F46E5",
                      strokeWidth: "1.6",
                      strokeLinecap: "round",
                      strokeLinejoin: "round"
                    }
                  )
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: route("cart.checkout"),
            className: "rounded-full w-full max-w-[280px] py-4 text-center justify-center items-center bg-indigo-600 font-semibold text-lg text-white flex transition-all duration-500 hover:bg-indigo-700",
            children: [
              "Continue to Payment",
              /* @__PURE__ */ jsx(
                "svg",
                {
                  className: "ml-2",
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "23",
                  height: "22",
                  viewBox: "0 0 23 22",
                  fill: "none",
                  children: /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M8.75324 5.49609L14.2535 10.9963L8.75 16.4998",
                      stroke: "white",
                      strokeWidth: "1.6",
                      strokeLinecap: "round",
                      strokeLinejoin: "round"
                    }
                  )
                }
              )
            ]
          }
        )
      ] })
    ] }) })
  ] });
}
export {
  Cart as default
};
