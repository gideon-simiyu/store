import { jsxs, jsx } from "react/jsx-runtime";
import { useState, Fragment } from "react";
import { A as ApplicationLogo, N as NavLink } from "./NavLink-DTY072R5.js";
import { T as ThemeSwitcher, H as Harmbuger } from "./Harmbuger-DjbFdboI.js";
function Authenticated({
  user,
  children
}) {
  const [showingNavigationDropdown, setShowingNavigationDropdown] = useState(false);
  return /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-h-screen", children: [
    /* @__PURE__ */ jsx("nav", { className: "bg-white shadow-lg dark:bg-slate-950 py-3.5 px-6  w-full lg:shadow-none fixed z-50", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-1 sm:gap-6 lg:flex-row flex-col", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center lg:w-auto w-full", children: [
        /* @__PURE__ */ jsx(ThemeSwitcher, { className: "lg:hidden" }),
        /* @__PURE__ */ jsx("a", { href: "#", className: "block", children: /* @__PURE__ */ jsx(ApplicationLogo, {}) }),
        /* @__PURE__ */ jsxs(
          "button",
          {
            id: "navbar-toggle",
            type: "button",
            className: "inline-flex items-center p-2 ml-3 text-sm  rounded-lg lg:hidden focus:outline-none ",
            "aria-controls": "navbar-default",
            "aria-expanded": "false",
            onClick: () => setShowingNavigationDropdown(
              !showingNavigationDropdown
            ),
            children: [
              /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Open main menu" }),
              /* @__PURE__ */ jsx(Harmbuger, { checked: showingNavigationDropdown })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxs(
        "div",
        {
          id: "mobile-navbar",
          className: `${!showingNavigationDropdown && "hidden"} lg:flex flex-row w-full flex-1`,
          style: { zIndex: 1e3 },
          children: [
            /* @__PURE__ */ jsx("ul", { className: "text-center flex lg:flex-row flex-col lg:gap-2 xl:gap-4 gap-2 items-start lg:ml-auto", children: user.is_staff == 1 ? /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("dashboard"),
                  active: route().current("dashboard"),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Dashboard" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("categories"),
                  active: route().current("categories"),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Categories" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("product_types"),
                  active: route().current(
                    "product_types"
                  ),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Types" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("products"),
                  active: route().current("products"),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Products" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("dashboard"),
                  active: route().current("orders"),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Orders" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("profile.edit"),
                  active: route().current("profile.edit"),
                  children: "Profile"
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("logout"),
                  method: "post",
                  active: route().current("logout"),
                  as: "button",
                  children: "Log Out"
                }
              )
            ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("home"),
                  active: route().current("home"),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Home" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("shop"),
                  active: route().current("shop"),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Shop" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("cart"),
                  active: route().current("cart"),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Cart" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("home"),
                  active: route().current("orders"),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Orders" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("profile.edit"),
                  active: route().current("profile.edit"),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Profile" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("logout"),
                  active: route().current("logout"),
                  method: "post",
                  as: "button",
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Logout" })
                }
              )
            ] }) }),
            /* @__PURE__ */ jsx("div", { className: "text-center lg:flex  items-center gap-1  sm:gap-4 lg:ml-auto", children: /* @__PURE__ */ jsx("div", { className: " flex items-center lg:justify-start justify-center gap-1 sm:gap-2 ", children: /* @__PURE__ */ jsx(ThemeSwitcher, { className: "hidden lg:inline-flex" }) }) })
          ]
        }
      )
    ] }) }),
    /* @__PURE__ */ jsx("div", { className: "pt-[68px] flex-grow flex flex-col bg-grey-200 text-grey-900 dark:text-grey-100 dark:bg-grey-900", children: /* @__PURE__ */ jsx("div", { className: "w-full flex-grow p-8", children }) })
  ] });
}
export {
  Authenticated as A
};
