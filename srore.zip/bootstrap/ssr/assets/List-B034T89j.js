import { jsx, jsxs } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-BLojdTCi.js";
import "react";
import "./NavLink-DTY072R5.js";
import "@inertiajs/react";
import "framer-motion";
import "@heroicons/react/24/solid";
import "@heroicons/react/24/outline";
function List({ auth, orders = [] }) {
  return /* @__PURE__ */ jsx(AdminLayout, { user: auth.user, children: /* @__PURE__ */ jsxs("div", { className: "rounded-sm bg-white py-6 px-3 md:px-7.5 shadow-default dark:bg-boxdark", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-title-md font-bold text-black dark:text-white", children: "Orders" }),
    /* @__PURE__ */ jsx("div", { className: "max-w-full overflow-x-auto mt-4", children: /* @__PURE__ */ jsxs("table", { className: "w-full table-auto", children: [
      /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-2 text-left dark:bg-meta-4", children: [
        /* @__PURE__ */ jsx("th", { className: "min-w-[220px] py-4 px-4 font-medium text-black dark:text-white xl:pl-11", children: "User" }),
        /* @__PURE__ */ jsx("th", { className: "min-w-[150px] py-4 px-4 font-medium text-black dark:text-white", children: "Products" }),
        /* @__PURE__ */ jsx("th", { className: "min-w-[120px] py-4 px-4 font-medium text-black dark:text-white", children: "Amount" }),
        /* @__PURE__ */ jsx("th", { className: "min-w-[120px] py-4 px-4 font-medium text-black dark:text-white", children: "Shipping Fee" }),
        /* @__PURE__ */ jsx("th", { className: "min-w-[120px] py-4 px-4 font-medium text-black dark:text-white", children: "Total" }),
        /* @__PURE__ */ jsx("th", { className: "min-w-[120px] py-4 px-4 font-medium text-black dark:text-white", children: "Status" }),
        /* @__PURE__ */ jsx("th", { className: "py-4 px-4 font-medium text-black dark:text-white", children: "Actions" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: orders.map((order, index) => /* @__PURE__ */ jsxs(
        "tr",
        {
          className: `${index % 2 === 0 ? "bg-grey-100 dark:bg-grey-900" : "bg-grey-200 dark:bg-grey-800"}`,
          children: [
            /* @__PURE__ */ jsx("td", { className: "py-4 px-4 font-medium text-black dark:text-white", children: order.user.name }),
            /* @__PURE__ */ jsx("td", { className: "py-4 px-4 font-medium text-black dark:text-white", children: order.products }),
            /* @__PURE__ */ jsx("td", { className: "py-4 px-4 font-medium text-black dark:text-white", children: order.amount })
          ]
        },
        index
      )) })
    ] }) })
  ] }) });
}
export {
  List as default
};
