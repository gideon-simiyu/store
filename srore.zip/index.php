<?php
echo phpinfo();