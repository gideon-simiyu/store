export default function Footer() {
  return (
    <div>
      powered by <a href="https://www.themoviedb.org/">TMDB</a>
    </div>
  );
}
