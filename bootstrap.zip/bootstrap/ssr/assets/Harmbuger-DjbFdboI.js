import { jsx, jsxs } from "react/jsx-runtime";
import { u as useColorMode, D as DarkModeSwitcher } from "./NavLink-DTY072R5.js";
function ThemeSwitcher({ className }) {
  useColorMode();
  return /* @__PURE__ */ jsx("div", { className: `relative cursor-pointer ${className}`, children: /* @__PURE__ */ jsx(DarkModeSwitcher, {}) });
}
function Harmbuger({ checked }) {
  return /* @__PURE__ */ jsxs("span", { className: "flex flex-col gap-2 w-8", children: [
    /* @__PURE__ */ jsx("input", { className: "peer hidden", checked, type: "checkbox" }),
    /* @__PURE__ */ jsx("div", { className: "rounded-2xl h-[3px] w-1/2 bg-black dark:bg-white duration-500 peer-checked:rotate-[225deg] origin-right peer-checked:-translate-x-[12px] peer-checked:-translate-y-[1px]" }),
    /* @__PURE__ */ jsx("div", { className: "rounded-2xl h-[3px] w-full bg-black duration-500 dark:bg-white peer-checked:-rotate-45" }),
    /* @__PURE__ */ jsx("div", { className: "rounded-2xl h-[3px] w-1/2 bg-black duration-500 dark:bg-white place-self-end peer-checked:rotate-[225deg] origin-left peer-checked:translate-x-[12px] peer-checked:translate-y-[1px]" })
  ] });
}
export {
  Harmbuger as H,
  ThemeSwitcher as T
};
