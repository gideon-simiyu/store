import { jsxs, jsx } from "react/jsx-runtime";
import { M as Modal } from "./Modal-BunpyNFw.js";
import { P as PrimaryButton } from "./PrimaryButton-namq1TfZ.js";
import { A as AdminLayout, f as formatDate } from "./AdminLayout-BLojdTCi.js";
import { useForm, Link } from "@inertiajs/react";
import { useState } from "react";
import "@headlessui/react";
import "framer-motion";
import "./NavLink-DTY072R5.js";
import "@heroicons/react/24/solid";
import "@heroicons/react/24/outline";
function List({
  auth,
  products = [],
  categories = [],
  productTypes = []
}) {
  const [showModal, setShowModal] = useState(false);
  const { data, setData, post, reset, errors } = useForm({
    category_id: "",
    product_type_id: "",
    name: "",
    description: "",
    price: "",
    image: null,
    quantity: "0"
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("products.create"), {
      preserveScroll: true,
      onSuccess: () => {
        reset();
        setShowModal(false);
      }
    });
  };
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteProduct, setDeleteProduct] = useState(null);
  const toggleDeleteModal = (Product) => {
    setDeleteProduct(Product);
    setShowDeleteModal(true);
  };
  console.log(products[0]);
  return /* @__PURE__ */ jsxs(AdminLayout, { user: auth.user, children: [
    /* @__PURE__ */ jsxs("div", { className: "rounded-sm bg-white py-6 px-3 md:px-7.5 shadow-default dark:bg-boxdark", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-title-md font-bold text-black dark:text-white", children: "Products" }),
        /* @__PURE__ */ jsx(PrimaryButton, { onClick: () => setShowModal(true), children: "Create Product" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "max-w-full overflow-x-auto mt-4", children: /* @__PURE__ */ jsxs("table", { className: "w-full table-auto", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-2 text-left dark:bg-meta-4", children: [
          /* @__PURE__ */ jsx("th", { className: "min-w-[220px] py-4 px-4 font-medium text-black dark:text-white xl:pl-11", children: "Product" }),
          /* @__PURE__ */ jsx("th", { className: "min-w-[150px] py-4 px-4 font-medium text-black dark:text-white", children: "Description" }),
          /* @__PURE__ */ jsx("th", { className: "min-w-[120px] py-4 px-4 font-medium text-black dark:text-white", children: "Category" }),
          /* @__PURE__ */ jsx("th", { className: "min-w-[120px] py-4 px-4 font-medium text-black dark:text-white", children: "Product Type" }),
          /* @__PURE__ */ jsx("th", { className: "min-w-[120px] py-4 px-4 font-medium text-black dark:text-white", children: "Created On" }),
          /* @__PURE__ */ jsx("th", { className: "py-4 px-4 font-medium text-black dark:text-white", children: "Updated On" }),
          /* @__PURE__ */ jsx("th", { className: "py-4 px-4 font-medium text-black dark:text-white", children: "Actions" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: products.map((Product, index) => /* @__PURE__ */ jsxs(
          "tr",
          {
            className: `${index % 2 === 0 ? "bg-grey-100 dark:bg-grey-900" : "bg-grey-200 dark:bg-grey-800"}`,
            children: [
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsx(
                  "img",
                  {
                    src: "/storage/" + Product.image,
                    alt: "",
                    className: "h-12 w-12"
                  }
                ),
                /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsx("h5", { className: "font-medium text-black dark:text-white", children: Product.name }),
                  /* @__PURE__ */ jsxs("p", { children: [
                    "£ ",
                    Product.price
                  ] })
                ] })
              ] }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: Product.description }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: Product.category.name }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: Product.product_type.name }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: formatDate(Product.created_at) }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: formatDate(Product.updated_at) }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsxs("p", { className: "text-black dark:text-white flex gap-5", children: [
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route("products.view", [Product.id]),
                    className: "text-blue-600 dark:text-blue-400",
                    children: "View"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "span",
                  {
                    className: "text-red-600 dark:text-red-400 cursor-pointer",
                    onClick: () => toggleDeleteModal(Product),
                    children: "Delete"
                  }
                )
              ] }) })
            ]
          },
          index
        )) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsx(Modal, { onClose: () => setShowModal(false), show: showModal, children: /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "p-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "category", className: "form-label", children: "Category" }),
        /* @__PURE__ */ jsxs(
          "select",
          {
            name: "category",
            id: "category",
            className: "form-input",
            value: data.category_id,
            onChange: (e) => setData("category_id", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "Select Category" }),
              categories.map((category) => /* @__PURE__ */ jsx("option", { value: category.id, children: category.name }, category.id))
            ]
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.category_id })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "product_type", className: "form-label", children: "Product Type" }),
        /* @__PURE__ */ jsxs(
          "select",
          {
            name: "product_type",
            id: "product_type",
            className: "form-input",
            value: data.product_type_id,
            onChange: (e) => setData("product_type_id", e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "Select Product Type" }),
              productTypes.map((productType) => /* @__PURE__ */ jsx(
                "option",
                {
                  value: productType.id,
                  children: productType.name
                },
                productType.id
              ))
            ]
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.product_type_id })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "name", className: "form-label", children: "Product Name" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            name: "name",
            id: "name",
            value: data.name,
            onChange: (e) => setData("name", e.target.value),
            className: "form-input"
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.name })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "name", className: "form-label", children: "Product Description" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            name: "description",
            id: "description",
            value: data.description,
            onChange: (e) => setData("description", e.target.value),
            className: "form-input"
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.description })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "name", className: "form-label", children: "Product Price" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            name: "price",
            id: "price",
            value: data.price,
            onChange: (e) => setData("price", e.target.value),
            className: "form-input"
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.price })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "image", className: "form-label", children: "Product Image" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "file",
            name: "image",
            id: "image",
            className: "form-input",
            onChange: (e) => setData("image", e.target.files[0])
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.image })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsx(PrimaryButton, { type: "submit", children: "Create Product" }) })
    ] }) }),
    /* @__PURE__ */ jsx(
      Modal,
      {
        onClose: () => setShowDeleteModal(false),
        show: showDeleteModal,
        children: /* @__PURE__ */ jsxs("div", { className: "p-3", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-white", children: [
            'Are you sure you want to delete Product "',
            deleteProduct == null ? void 0 : deleteProduct.name,
            '"'
          ] }),
          "resources/js/Pages/Admin/Type/List.tsx"
        ] })
      }
    )
  ] });
}
export {
  List as default
};
