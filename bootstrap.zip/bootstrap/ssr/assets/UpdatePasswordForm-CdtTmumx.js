import { jsxs, jsx } from "react/jsx-runtime";
import { useRef } from "react";
import { P as PrimaryButton } from "./PrimaryButton-namq1TfZ.js";
import { useForm } from "@inertiajs/react";
import { Transition } from "@headlessui/react";
import { LockOpenIcon, LockClosedIcon } from "@heroicons/react/24/outline";
import "framer-motion";
function UpdatePasswordForm({
  className = ""
}) {
  const passwordInput = useRef(null);
  const currentPasswordInput = useRef(null);
  const { data, setData, errors, put, reset, processing, recentlySuccessful } = useForm({
    current_password: "",
    password: "",
    password_confirmation: ""
  });
  const updatePassword = (e) => {
    e.preventDefault();
    put(route("password.update"), {
      preserveScroll: true,
      onSuccess: () => reset(),
      onError: (errors2) => {
        var _a, _b;
        if (errors2.password) {
          reset("password", "password_confirmation");
          (_a = passwordInput.current) == null ? void 0 : _a.focus();
        }
        if (errors2.current_password) {
          reset("current_password");
          (_b = currentPasswordInput.current) == null ? void 0 : _b.focus();
        }
      }
    });
  };
  return /* @__PURE__ */ jsxs("section", { className, children: [
    /* @__PURE__ */ jsxs("header", { children: [
      /* @__PURE__ */ jsx("h2", { className: "text-lg font-medium text-gray-900 dark:text-gray-100", children: "Update Password" }),
      /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-gray-600 dark:text-gray-400", children: "Ensure your account is using a long, random password to stay secure." })
    ] }),
    /* @__PURE__ */ jsxs("form", { onSubmit: updatePassword, className: "mt-6 space-y-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-2.5 block font-medium text-black dark:text-white", children: "Current Password" }),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "password",
              placeholder: "Enter your current password",
              value: data.current_password,
              onChange: (e) => setData("current_password", e.target.value),
              className: "w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary",
              required: true
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "absolute right-4 top-4", children: /* @__PURE__ */ jsx(LockOpenIcon, { className: "w-6 h-6" }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.current_password })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-2.5 block font-medium text-black dark:text-white", children: "New Password" }),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              id: "password",
              ref: passwordInput,
              value: data.password,
              placeholder: "Enter your new password",
              onChange: (e) => setData("password", e.target.value),
              type: "password",
              className: "w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary",
              required: true
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "absolute right-4 top-4", children: /* @__PURE__ */ jsx(LockClosedIcon, { className: "w-6 h-6" }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.password })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-2.5 block font-medium text-black dark:text-white", children: "Confirm Password" }),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              id: "password_confirmation",
              value: data.password_confirmation,
              onChange: (e) => setData("password_confirmation", e.target.value),
              type: "password",
              placeholder: "Re-enter your new password",
              className: "w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary",
              required: true
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "absolute right-4 top-4", children: /* @__PURE__ */ jsx(LockClosedIcon, { className: "w-6 h-6" }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.password_confirmation })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsx(PrimaryButton, { disabled: processing, children: "Save" }),
        /* @__PURE__ */ jsx(
          Transition,
          {
            show: recentlySuccessful,
            enter: "transition ease-in-out",
            enterFrom: "opacity-0",
            leave: "transition ease-in-out",
            leaveTo: "opacity-0",
            children: /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-600 dark:text-gray-400", children: "Saved." })
          }
        )
      ] })
    ] })
  ] });
}
export {
  UpdatePasswordForm as default
};
