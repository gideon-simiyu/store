import { jsxs, jsx } from "react/jsx-runtime";
import { G as Guest } from "./GuestLayout-CF0LXAnb.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { A as ApplicationLogo } from "./NavLink-DTY072R5.js";
import { UserIcon, EnvelopeIcon, LockClosedIcon } from "@heroicons/react/24/outline";
import "react";
import "./Harmbuger-DjbFdboI.js";
import "framer-motion";
function Register() {
  const { data, setData, post, processing, errors, reset } = useForm({
    name: "",
    email: "",
    password: "",
    password_confirmation: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("register"), {
      onFinish: () => reset("password", "password_confirmation")
    });
  };
  return /* @__PURE__ */ jsxs(Guest, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Create Account" }),
    /* @__PURE__ */ jsxs("form", { className: "p-5 mx-auto", onSubmit: submit, children: [
      /* @__PURE__ */ jsx("div", { className: "flex justify-center w-full", children: /* @__PURE__ */ jsx(ApplicationLogo, {}) }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-center font-manrope text-3xl font-bold leading-10 mb-2", children: "Welcome Back" }),
        /* @__PURE__ */ jsx("p", { className: "text-indigo-500 text-center text-base font-medium leading-6", children: "Log in to your account to continue" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-2.5 block font-medium text-black dark:text-white", children: "Name" }),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              placeholder: "Enter your name",
              value: data.name,
              onChange: (e) => setData("name", e.target.value),
              className: "w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary",
              required: true
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "absolute right-4 top-4", children: /* @__PURE__ */ jsx(UserIcon, { className: "w-6 h-6" }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.name })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-2.5 block font-medium text-black dark:text-white", children: "Email" }),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "email",
              placeholder: "Enter your email",
              value: data.email,
              onChange: (e) => setData("email", e.target.value),
              className: "w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary",
              required: true
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "absolute right-4 top-4", children: /* @__PURE__ */ jsx(EnvelopeIcon, { className: "w-6 h-6" }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.email })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-2.5 block font-medium text-black dark:text-white", children: "Password" }),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "password",
              placeholder: "Enter your password",
              value: data.password,
              onChange: (e) => setData("password", e.target.value),
              className: "w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary",
              required: true
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "absolute right-4 top-4", children: /* @__PURE__ */ jsx(LockClosedIcon, { className: "w-6 h-6" }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.password })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-2.5 block font-medium text-black dark:text-white", children: "Confirm Password" }),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "password",
              placeholder: "Re-Enter your password",
              value: data.password_confirmation,
              onChange: (e) => setData("password_confirmation", e.target.value),
              className: "w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary",
              required: true
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "absolute right-4 top-4", children: /* @__PURE__ */ jsx(LockClosedIcon, { className: "w-6 h-6" }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.password_confirmation })
      ] }),
      /* @__PURE__ */ jsx("button", { className: "w-full mt-6 h-12 text-white text-center text-base font-semibold leading-6 rounded-full hover:bg-indigo-800 transition-all duration-700 bg-indigo-600 shadow-sm mb-11", children: "Register" }),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: route("login"),
          className: "flex justify-center text-base font-medium leading-6",
          children: [
            "ALready have an account?",
            /* @__PURE__ */ jsx("span", { className: "text-indigo-500 font-semibold pl-3", children: " Sign In" })
          ]
        }
      )
    ] })
  ] });
}
export {
  Register as default
};
