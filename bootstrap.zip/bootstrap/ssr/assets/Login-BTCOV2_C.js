import { jsx, jsxs } from "react/jsx-runtime";
import { G as Guest } from "./GuestLayout-CF0LXAnb.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { useState } from "react";
import { A as ApplicationLogo } from "./NavLink-DTY072R5.js";
import { EnvelopeIcon, LockClosedIcon } from "@heroicons/react/24/outline";
import "./Harmbuger-DjbFdboI.js";
import "framer-motion";
function Checkbox({ className = "", ...props }) {
  return /* @__PURE__ */ jsx(
    "input",
    {
      ...props,
      type: "checkbox",
      className: "rounded dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800 " + className
    }
  );
}
function Login({
  status,
  canResetPassword
}) {
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: false
  });
  const [passwordShown, setPasswordShown] = useState(false);
  const togglePasswordVisiblity = () => {
    setPasswordShown(passwordShown ? false : true);
  };
  const submit = (e) => {
    e.preventDefault();
    post(route("login"), {
      onFinish: () => reset("password")
    });
  };
  return /* @__PURE__ */ jsxs(Guest, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Log in" }),
    status && /* @__PURE__ */ jsx("div", { className: "mb-4 font-medium text-green-600", children: status }),
    /* @__PURE__ */ jsxs("form", { className: "mx-auto p-4", onSubmit: submit, children: [
      /* @__PURE__ */ jsx("div", { className: "flex justify-center w-full", children: /* @__PURE__ */ jsx(ApplicationLogo, {}) }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-center font-manrope text-3xl font-bold leading-10 mb-2", children: "Welcome Back" }),
        /* @__PURE__ */ jsx("p", { className: "text-indigo-500 text-center text-base font-medium leading-6", children: "Log in to your account to continue" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-2.5 block font-medium text-black dark:text-white", children: "Email" }),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "email",
              placeholder: "Enter your email",
              value: data.email,
              onChange: (e) => setData("email", e.target.value),
              className: "w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary",
              required: true
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "absolute right-4 top-4", children: /* @__PURE__ */ jsx(EnvelopeIcon, { className: "w-6 h-6" }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.email })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "mb-2.5 block font-medium text-black dark:text-white", children: "Password" }),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: passwordShown ? "text" : "password",
              placeholder: "Enter your password",
              value: data.password,
              onChange: (e) => setData("password", e.target.value),
              className: "w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary",
              required: true
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "absolute right-4 top-4", children: /* @__PURE__ */ jsx(LockClosedIcon, { className: "w-6 h-6" }) })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.password })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-6", children: [
        /* @__PURE__ */ jsxs(
          "label",
          {
            htmlFor: "show_password",
            className: "flex items-center cursor-pointer",
            children: [
              /* @__PURE__ */ jsx(
                Checkbox,
                {
                  name: "show_password",
                  id: "show_password",
                  checked: data.remember,
                  onChange: togglePasswordVisiblity
                }
              ),
              /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Show password" })
            ]
          }
        ),
        canResetPassword && /* @__PURE__ */ jsx(
          Link,
          {
            href: route("password.request"),
            className: "underline text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-slate-800",
            children: "Forgot your password?"
          }
        )
      ] }),
      /* @__PURE__ */ jsx("button", { className: "w-full mt-6 h-12 text-white text-center text-base font-semibold leading-6 rounded-full hover:bg-indigo-800 transition-all duration-700 bg-indigo-600 shadow-sm mb-11", children: "Login" }),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: route("register"),
          className: "flex justify-center text-base font-medium leading-6",
          children: [
            "Don’t have an account?",
            /* @__PURE__ */ jsx("span", { className: "text-indigo-500 font-semibold pl-3", children: " Sign Up" })
          ]
        }
      )
    ] })
  ] });
}
export {
  Login as default
};
