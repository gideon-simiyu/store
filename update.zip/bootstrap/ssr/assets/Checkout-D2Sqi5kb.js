import { jsx, jsxs } from "react/jsx-runtime";
import { P as PrimaryButton } from "./PrimaryButton-namq1TfZ.js";
import { A as Authenticated } from "./AuthenticatedLayout-B0RmSo8o.js";
import { useForm } from "@inertiajs/react";
import { useState, useEffect } from "react";
import "framer-motion";
import "./NavLink-DTY072R5.js";
import "./Harmbuger-DjbFdboI.js";
function Checkout({
  auth,
  cart,
  products = [],
  total,
  shippings = [
    {
      id: 1,
      name: "Standard",
      delivery: "2-4 Days",
      fee: 10
    },
    {
      id: 2,
      name: "Express",
      delivery: "1-2 days",
      fee: 30
    }
  ]
}) {
  const { data, setData, reset, errors, post } = useForm({
    email: auth.user.email,
    name: auth.user.name,
    card_number: "",
    cvc: "",
    expiry: "",
    address: "",
    state: "",
    zip: ""
  });
  const handleSubmit = (event) => {
  };
  const [shipping_fee, setShippingFee] = useState(shippings[0].fee);
  const handleShippingChange = (event) => {
    const shipping_id = event.target.value;
    setShippingFee(
      shippings.find((shipping) => shipping.id == shipping_id).fee
    );
  };
  useEffect(() => {
  }, []);
  return /* @__PURE__ */ jsx(Authenticated, { user: auth.user, children: /* @__PURE__ */ jsxs("div", { className: "grid sm:px-10 lg:grid-cols-2 lg:px-20 xl:px-32 bg-white dark:bg-grey-800", children: [
    /* @__PURE__ */ jsxs("div", { className: "px-4 pt-8", children: [
      /* @__PURE__ */ jsx("p", { className: "text-xl font-medium", children: "Order Summary" }),
      /* @__PURE__ */ jsx("p", { className: "text-grey-400", children: "Check your items. And select a suitable shipping method." }),
      /* @__PURE__ */ jsx("div", { className: "mt-8 h-70 overflow-y-auto space-y-3 rounded-lg border border-grey-200 dark:border-grey-700 bg-white dark:bg-grey-800 px-2 py-4 sm:px-6", children: products.map((product, index) => {
        return /* @__PURE__ */ jsxs(
          "div",
          {
            className: "flex",
            children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  className: "m-2 h-24 w-28 rounded-md border object-cover object-center",
                  src: "/storage/" + product.image,
                  alt: ""
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "flex w-full flex-col px-4 py-4", children: [
                /* @__PURE__ */ jsx("span", { className: "font-semibold", children: product.name }),
                /* @__PURE__ */ jsxs("span", { className: "float-right text-grey-400", children: [
                  "£ ",
                  product.price,
                  " X",
                  " ",
                  product.pivot.quantity
                ] }),
                /* @__PURE__ */ jsxs("p", { className: "text-lg font-bold", children: [
                  "£",
                  " ",
                  product.price * product.pivot.quantity
                ] })
              ] })
            ]
          },
          index
        );
      }) }),
      /* @__PURE__ */ jsx("p", { className: "mt-8 text-lg font-medium", children: "Shipping Methods" }),
      /* @__PURE__ */ jsx("form", { onSubmit: handleSubmit, className: "mt-5 grid gap-6", children: shippings.map((shipping, index) => /* @__PURE__ */ jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsx(
          "input",
          {
            className: "peer hidden",
            id: "shipping_" + shipping.id,
            type: "radio",
            name: "shipping",
            onChange: handleShippingChange,
            value: shipping.id
          }
        ),
        /* @__PURE__ */ jsx("span", { className: "peer-checked:border-indigo-700 dark:peer-checked:border-indigo-500 absolute right-4 top-1/2 box-content block h-3 w-3 -translate-y-1/2 rounded-full border-8 border-grey-300" }),
        /* @__PURE__ */ jsx(
          "label",
          {
            className: "peer-checked:border-2 peer-checked:border-indigo-700 dark:peer-checked:border-indigo-500 flex cursor-pointer select-none rounded-lg border border-grey-300 p-4",
            htmlFor: "shipping_" + shipping.id,
            children: /* @__PURE__ */ jsxs("div", { className: "ml-5", children: [
              /* @__PURE__ */ jsxs("span", { className: "mt-2 font-semibold", children: [
                shipping.name,
                " @ ",
                /* @__PURE__ */ jsxs("span", { children: [
                  "£ ",
                  shipping.fee
                ] })
              ] }),
              /* @__PURE__ */ jsxs("p", { className: "text-slate-500 text-sm leading-6", children: [
                "Delivery: ",
                shipping.delivery
              ] })
            ] })
          }
        )
      ] }, index)) })
    ] }),
    /* @__PURE__ */ jsxs("form", { className: "mt-10 bg-white dark:bg-grey-800 px-4 pt-8 lg:mt-0", children: [
      /* @__PURE__ */ jsx("p", { className: "text-xl font-medium", children: "Payment Details" }),
      /* @__PURE__ */ jsx("p", { className: "text-grey-400", children: "Complete your order by providing your payment details." }),
      /* @__PURE__ */ jsxs("div", { className: "", children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "email",
            className: "mt-4 mb-2 block text-sm font-medium",
            children: "Email"
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              id: "email",
              name: "email",
              className: "form-input px-8",
              placeholder: "your.email@gmail.com",
              value: data.email,
              onChange: (e) => setData("email", e.target.value),
              required: true
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-y-0 left-0 inline-flex items-center px-3", children: /* @__PURE__ */ jsx(
            "svg",
            {
              xmlns: "http://www.w3.org/2000/svg",
              className: "h-4 w-4 text-grey-400",
              fill: "none",
              viewBox: "0 0 24 24",
              stroke: "currentColor",
              "stroke-width": "2",
              children: /* @__PURE__ */ jsx(
                "path",
                {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207"
                }
              )
            }
          ) })
        ] }),
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "card-holder",
            className: "mt-4 mb-2 block text-sm font-medium",
            children: "Card Holder"
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              id: "card-holder",
              name: "card-holder",
              className: "form-input px-8",
              placeholder: "Your full name here",
              value: data.name,
              onChange: (e) => setData("name", e.target.value),
              required: true
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-y-0 left-0 inline-flex items-center px-3", children: /* @__PURE__ */ jsx(
            "svg",
            {
              xmlns: "http://www.w3.org/2000/svg",
              className: "h-4 w-4 text-grey-400",
              fill: "none",
              viewBox: "0 0 24 24",
              stroke: "currentColor",
              "stroke-width": "2",
              children: /* @__PURE__ */ jsx(
                "path",
                {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M15 9h3.75M15 12h3.75M15 15h3.75M4.5 19.5h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5zm6-10.125a1.875 1.875 0 11-3.75 0 1.875 1.875 0 013.75 0zm1.294 6.336a6.721 6.721 0 01-3.17.789 6.721 6.721 0 01-3.168-.789 3.376 3.376 0 016.338 0z"
                }
              )
            }
          ) })
        ] }),
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "card-no",
            className: "mt-4 mb-2 block text-sm font-medium",
            children: "Card Details"
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "relative w-7/12 flex-shrink-0", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                id: "card-no",
                name: "card-no",
                className: "form-input px-8",
                placeholder: "xxxx-xxxx-xxxx-xxxx",
                value: data.card_number,
                onChange: (e) => setData("card_number", e.target.value),
                required: true
              }
            ),
            /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-y-0 left-0 inline-flex items-center px-3", children: /* @__PURE__ */ jsxs(
              "svg",
              {
                className: "h-4 w-4 text-grey-400",
                xmlns: "http://www.w3.org/2000/svg",
                width: "16",
                height: "16",
                fill: "currentColor",
                viewBox: "0 0 16 16",
                children: [
                  /* @__PURE__ */ jsx("path", { d: "M11 5.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1z" }),
                  /* @__PURE__ */ jsx("path", { d: "M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2zm13 2v5H1V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1zm-1 9H2a1 1 0 0 1-1-1v-1h14v1a1 1 0 0 1-1 1z" })
                ]
              }
            ) })
          ] }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              name: "credit-expiry",
              className: "form-input",
              placeholder: "MM/YY",
              value: data.expiry,
              onChange: (e) => setData("expiry", e.target.value),
              required: true
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              name: "credit-cvc",
              className: "form-input",
              placeholder: "CVC",
              value: data.cvc,
              onChange: (e) => setData("cvc", e.target.value),
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "billing-address",
            className: "mt-4 mb-2 block text-sm font-medium",
            children: "Billing Address"
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row gap-3", children: [
          /* @__PURE__ */ jsx("div", { className: "relative flex-shrink-0 sm:w-7/12", children: /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              id: "billing-address",
              name: "billing-address",
              className: "form-input",
              placeholder: "Street Address",
              value: data.address,
              onChange: (e) => setData("address", e.target.value),
              required: true
            }
          ) }),
          /* @__PURE__ */ jsx(
            "select",
            {
              name: "billing-state",
              className: "form-input px-8",
              value: data.state,
              onChange: (e) => setData("state", e.target.value),
              children: /* @__PURE__ */ jsx("option", { value: "State", children: "State" })
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              name: "billing-zip",
              className: "form-input px-8",
              placeholder: "ZIP",
              value: data.zip,
              onChange: (e) => setData("zip", e.target.value),
              required: true
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-6 border-t border-b py-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsx("p", { className: "text-sm font-medium", children: "Subtotal" }),
            /* @__PURE__ */ jsxs("p", { className: "font-semibold", children: [
              "£ ",
              total
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsx("p", { className: "text-sm font-medium", children: "Shipping" }),
            /* @__PURE__ */ jsxs("p", { className: "font-semibold", children: [
              "£ ",
              shipping_fee
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-6 flex items-center justify-between", children: [
          /* @__PURE__ */ jsx("p", { className: "text-sm font-medium", children: "Total" }),
          /* @__PURE__ */ jsxs("p", { className: "text-2xl font-semibold", children: [
            "£ ",
            total + shipping_fee
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end my-4", children: /* @__PURE__ */ jsx(PrimaryButton, { children: "Place Order" }) })
    ] })
  ] }) });
}
export {
  Checkout as default
};
