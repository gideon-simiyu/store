import { jsx, jsxs } from "react/jsx-runtime";
import ReactDOM from "react-dom";
import React from "react";
import { AnimatePresence, motion } from "framer-motion";
function Messaging({
  message,
  mtype,
  show,
  onClose
}) {
  React.useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onClose();
      }, 5e3);
      return () => clearTimeout(timer);
    }
  }, [show]);
  const variants = {
    hidden: { opacity: 0, y: -50 },
    // initial state: above the screen and invisible
    visible: { opacity: 1, y: 0 },
    // animate to: visible and in place
    exit: { opacity: 0, y: -50 }
    // exit animation: move back up and fade out
  };
  const content = /* @__PURE__ */ jsx(AnimatePresence, { children: show && /* @__PURE__ */ jsx(
    motion.div,
    {
      style: { zIndex: 99999 },
      className: "fixed h-fit w-fit right-4 top-4 z-50",
      initial: "hidden",
      animate: "visible",
      exit: "exit",
      variants,
      transition: { duration: 0.5, type: "spring" },
      children: /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-2 w-fit text-lg z-50", children: /* @__PURE__ */ jsxs("div", { className: "success-alert cursor-default flex items-center justify-between w-fit rounded-lg bg-indigo-500 px-[10px] shadow-lg", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-white bg-white/5 backdrop-blur-xl p-3 rounded-lg", children: [
            mtype === "success" && /* @__PURE__ */ jsx(
              "svg",
              {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                strokeWidth: "1.5",
                stroke: "green",
                className: "w-6 h-6",
                children: /* @__PURE__ */ jsx(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "m4.5 12.75 6 6 9-13.5"
                  }
                )
              }
            ),
            mtype === "error" && /* @__PURE__ */ jsx(
              "svg",
              {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                strokeWidth: "1.5",
                stroke: "currentColor",
                className: "w-6 h-6",
                children: /* @__PURE__ */ jsx(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1-18 0Zm-9 3.75h.008v.008H12v-.008Z"
                  }
                )
              }
            ),
            mtype === "message" && /* @__PURE__ */ jsx(
              "svg",
              {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                strokeWidth: "1.8",
                stroke: "currentColor",
                className: "w-6 h-6 shadow-[#1c569e]",
                children: /* @__PURE__ */ jsx(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M12 20.25c4.97 0 9-3.694 9-8.25s-4.03-8.25-9-8.25S3 7.444 3 12c0 2.104.859 4.023 2.273 5.48.432.447.74 1.04.586 1.641a4.483 4.483 0 0 1-.923 1.785A5.969 5.969 0 0 0 6 21c1.282 0 2.47-.402 3.445-1.087.81.22 1.668.337 2.555.337Z"
                  }
                )
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("p", { className: "text-white font-bold", children: mtype === "success" ? "Success" : mtype === "error" ? "Error" : "Message" }),
            /* @__PURE__ */ jsx("p", { className: "text-gray-100 text-base", children: message })
          ] })
        ] }),
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "text-gray-100 hover:bg-white/5 p-1 rounded-md transition-colors ease-linear",
            onClick: onClose,
            children: /* @__PURE__ */ jsx(
              "svg",
              {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                strokeWidth: "1.5",
                stroke: "currentColor",
                className: "w-6 h-6",
                children: /* @__PURE__ */ jsx(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M6 18 18 6M6 6l12 12"
                  }
                )
              }
            )
          }
        )
      ] }) })
    }
  ) });
  return ReactDOM.createPortal(content, document.body);
}
export {
  Messaging as M
};
