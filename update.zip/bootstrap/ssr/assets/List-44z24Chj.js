import { jsxs, jsx } from "react/jsx-runtime";
import { D as DangerButton } from "./DangerButton-1tnFs2BV.js";
import { M as Messaging } from "./Messaging-x51nvob9.js";
import { M as Modal } from "./Modal-BunpyNFw.js";
import { P as PrimaryButton } from "./PrimaryButton-namq1TfZ.js";
import { A as AdminLayout, f as formatDate } from "./AdminLayout-BLojdTCi.js";
import { useForm, Link, router } from "@inertiajs/react";
import { useState } from "react";
import "react-dom";
import "framer-motion";
import "@headlessui/react";
import "./NavLink-DTY072R5.js";
import "@heroicons/react/24/solid";
import "@heroicons/react/24/outline";
function List({ auth, categories = [] }) {
  const [showModal, setShowModal] = useState(false);
  const { data, setData, post, reset, errors } = useForm({
    name: "",
    description: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("categories.create"), {
      preserveScroll: true,
      onSuccess: () => {
        reset();
        setShowModal(false);
        setMessaging({
          type: "success",
          message: "Category added successfully.",
          show: true
        });
      }
    });
  };
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteCategory, setDeleteCategory] = useState(null);
  const toggleDeleteModal = (category) => {
    setDeleteCategory(category);
    setShowDeleteModal(true);
  };
  const [messaging, setMessaging] = useState({
    type: "",
    message: "",
    show: false
  });
  const confirmDelete = (e) => {
    e.preventDefault();
    router.delete(route("categories.delete", [deleteCategory.id]), {
      preserveScroll: true,
      onSuccess: () => {
        setShowDeleteModal(false);
        setDeleteCategory(null);
        setMessaging({
          type: "success",
          message: "Category deleted successfully.",
          show: true
        });
      }
    });
  };
  const onClose = () => {
    setMessaging({ ...messaging, show: false });
  };
  return /* @__PURE__ */ jsxs(AdminLayout, { user: auth.user, children: [
    /* @__PURE__ */ jsx(Messaging, { onClose, mtype: messaging.type, message: messaging.message, show: messaging.show }),
    /* @__PURE__ */ jsxs("div", { className: "rounded-sm bg-white py-6 px-3 md:px-7.5 shadow-default dark:bg-boxdark", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-title-md font-bold text-black dark:text-white", children: "Categories" }),
        /* @__PURE__ */ jsx(PrimaryButton, { onClick: () => setShowModal(true), children: "Create category" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "max-w-full overflow-x-auto mt-4", children: /* @__PURE__ */ jsxs("table", { className: "w-full table-auto", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-2 text-left dark:bg-meta-4", children: [
          /* @__PURE__ */ jsx("th", { className: "min-w-[220px] py-4 px-4 font-medium text-black dark:text-white xl:pl-11", children: "Name" }),
          /* @__PURE__ */ jsx("th", { className: "min-w-[150px] py-4 px-4 font-medium text-black dark:text-white", children: "Description" }),
          /* @__PURE__ */ jsx("th", { className: "min-w-[120px] py-4 px-4 font-medium text-black dark:text-white", children: "Created On" }),
          /* @__PURE__ */ jsx("th", { className: "py-4 px-4 font-medium text-black dark:text-white", children: "Updated On" }),
          /* @__PURE__ */ jsx("th", { className: "py-4 px-4 font-medium text-black dark:text-white", children: "Actions" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: categories.map((category, index) => /* @__PURE__ */ jsxs(
          "tr",
          {
            className: `${index % 2 === 0 ? "bg-grey-100 dark:bg-grey-900" : "bg-grey-200 dark:bg-grey-800"}`,
            children: [
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("h5", { className: "font-medium text-black dark:text-white", children: category.name }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: category.description }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: formatDate(category.created_at) }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: formatDate(category.updated_at) }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsxs("p", { className: "text-black dark:text-white flex gap-5", children: [
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route("categories.view", [category.id]),
                    className: "text-blue-600 dark:text-blue-400",
                    children: "View"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "span",
                  {
                    className: "text-red-600 dark:text-red-400 cursor-pointer",
                    onClick: () => toggleDeleteModal(category),
                    children: "Delete"
                  }
                )
              ] }) })
            ]
          },
          index
        )) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsx(Modal, { onClose: () => setShowModal(false), show: showModal, children: /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "p-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "name", className: "form-label", children: "Category Name" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            name: "name",
            id: "name",
            value: data.name,
            onChange: (e) => setData("name", e.target.value),
            className: "form-input"
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.name })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "name", className: "form-label", children: "Category Description" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            name: "description",
            id: "description",
            value: data.description,
            onChange: (e) => setData("description", e.target.value),
            className: "form-input"
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.description })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsx(PrimaryButton, { children: "Create Category" }) })
    ] }) }),
    /* @__PURE__ */ jsx(Modal, { onClose: () => setShowDeleteModal(false), show: showDeleteModal, children: /* @__PURE__ */ jsxs("div", { className: "p-5", children: [
      /* @__PURE__ */ jsxs("p", { className: "text-white", children: [
        'Are you sure you want to delete category "',
        deleteCategory == null ? void 0 : deleteCategory.name,
        '"'
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-4 mt-3", children: [
        /* @__PURE__ */ jsx(PrimaryButton, { onClick: () => setShowDeleteModal(false), children: "Cancel" }),
        /* @__PURE__ */ jsx(DangerButton, { onClick: confirmDelete, children: "Delete" })
      ] })
    ] }) })
  ] });
}
export {
  List as default
};
