import { jsxs, jsx } from "react/jsx-runtime";
import { I as InputLabel } from "./InputLabel-CaoVq05r.js";
import { M as Messaging } from "./Messaging-x51nvob9.js";
import { P as PrimaryButton } from "./PrimaryButton-namq1TfZ.js";
import { T as TextInput } from "./TextInput-BcQtEsKK.js";
import { A as Authenticated } from "./AuthenticatedLayout-B0RmSo8o.js";
import { StarIcon, ShoppingCartIcon } from "@heroicons/react/24/outline";
import { useForm } from "@inertiajs/react";
import { useState, Fragment } from "react";
import "react-dom";
import "framer-motion";
import "./NavLink-DTY072R5.js";
import "./Harmbuger-DjbFdboI.js";
function View({ auth, product, sizes = [], reviews = [] }) {
  var _a;
  const rating = parseInt(product.rating.toString());
  const unrated = 5 - rating;
  const [message, setMessage] = useState({
    type: "",
    message: "",
    show: false
  });
  const { data, setData, post, processing, errors, reset, patch } = useForm({
    product_id: product.id,
    size: "",
    quantity: 1,
    name: product.name,
    description: product.description,
    price: product.price,
    discount: product.discount,
    category_id: product.category_id,
    product_type_id: product.product_type_id
  });
  const submit = (e) => {
    var _a2;
    e.preventDefault();
    if ((_a2 = auth == null ? void 0 : auth.user) == null ? void 0 : _a2.is_staff) {
      patch(route("products.update", product.id), {
        onFinish: () => {
          setMessage({
            type: "success",
            message: "Product updated successfully",
            show: true
          });
        },
        onError: () => {
          setMessage({
            type: "error",
            message: "An error occurred. Please try again",
            show: true
          });
        }
      });
      return;
    }
    post(route("cart.add"), {
      onFinish: () => reset("quantity"),
      onSuccess: () => {
        setMessage({
          type: "success",
          message: "Product added to cart",
          show: true
        });
      },
      onError: () => {
        setMessage({
          type: "error",
          message: "An error occurred. Please try again",
          show: true
        });
      }
    });
  };
  const onClose = () => {
    setMessage({ ...message, show: false });
  };
  return /* @__PURE__ */ jsxs(Authenticated, { user: auth.user, children: [
    /* @__PURE__ */ jsx(
      Messaging,
      {
        mtype: message.type,
        message: message.message,
        show: message.show,
        onClose
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "mx-auto mt-16", children: /* @__PURE__ */ jsx("section", { className: "relative max-w-6xl mx-auto", children: /* @__PURE__ */ jsx("div", { className: "w-full mx-auto px-4 sm:px-6 lg:px-0", children: /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-16 mx-auto max-md:px-2 ", children: [
      /* @__PURE__ */ jsx("div", { className: "img", children: /* @__PURE__ */ jsx("div", { className: "h-full max-lg:mx-auto rounded-xl bg-gray-300 dark:bg-gray-800 p-2", children: /* @__PURE__ */ jsx(
        "img",
        {
          src: `/storage/${product.image}`,
          alt: product.name,
          className: "max-lg:mx-auto lg:ml-auto h-full rounded-lg"
        }
      ) }) }),
      /* @__PURE__ */ jsx("div", { className: "data w-full lg:pr-8 pr-0 xl:justify-start justify-center flex items-start max-lg:pb-10 xl:my-2 lg:my-5 my-0", children: /* @__PURE__ */ jsxs("div", { className: "data w-full max-w-xl", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-lg font-medium leading-8 text-indigo-600 mb-4", children: [
          /* @__PURE__ */ jsx("span", { className: "capitalize", children: product.category.name }),
          "  / ",
          " ",
          /* @__PURE__ */ jsx("span", { className: "capitalize", children: product.product_type.name })
        ] }),
        /* @__PURE__ */ jsx("h2", { className: "font-manrope font-bold text-3xl leading-10 mb-2 capitalize", children: product.name }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center mb-6", children: [
          /* @__PURE__ */ jsxs("h6", { className: "font-manrope font-semibold text-2xl leading-9 pr-5 sm:border-r border-gray-200 mr-5", children: [
            "£",
            product.price
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1", children: [
              rating > 0 && Array.from({ length: rating }, (_, i) => /* @__PURE__ */ jsx(
                StarIcon,
                {
                  className: "h-5 w-5 text-indigo-600 dark:text-indigo-400"
                },
                i
              )),
              rating > 0 && Array.from({ length: unrated }, (_, i) => /* @__PURE__ */ jsx(
                StarIcon,
                {
                  className: "h-5 w-5 text-gray-400"
                },
                i
              )),
              /* @__PURE__ */ jsx("span", { className: "mr-2 ml-3 rounded bg-indigo-600 text-white px-2.5 py-0.5 text-xs font-semibold", children: rating > 0 ? `${rating} stars` : "Unrated" })
            ] }),
            /* @__PURE__ */ jsxs("span", { className: "pl-2 font-normal leading-7 text-sm ", children: [
              reviews.length,
              " reviews"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-base font-normal mb-5", children: product.description }),
        sizes.length > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx("p", { className: " text-lg leading-8 font-medium mb-4", children: "Size" }),
          /* @__PURE__ */ jsx("div", { className: "w-full pb-8 border-b border-gray-100 flex-wrap", children: /* @__PURE__ */ jsx("div", { className: "grid grid-cols-3 min-[400px]:grid-cols-5 gap-3 max-w-md", children: sizes.map((size) => /* @__PURE__ */ jsx("button", { className: "text-center py-1.5 px-6 w-full font-semibold text-lg leading-8 border border-indigo-600 flex items-center rounded-full justify-center transition-all duration-300 hover:bg-indigo-600 hover:text-white", children: size.size })) }) })
        ] }),
        ((_a = auth == null ? void 0 : auth.user) == null ? void 0 : _a.is_staff) ? /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "flex flex-col", children: [
          /* @__PURE__ */ jsxs("div", { className: "my-3", children: [
            /* @__PURE__ */ jsx(InputLabel, { htmlFor: "name", value: "Product Name" }),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "name",
                name: "name",
                value: data.name,
                onChange: (e) => setData("name", e.target.value),
                required: true
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "my-3", children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "description",
                value: "Product Description"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "description",
                name: "description",
                value: data.description,
                onChange: (e) => setData("description", e.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "my-3", children: [
            /* @__PURE__ */ jsx(InputLabel, { htmlFor: "price", value: "Product Price" }),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "price",
                name: "price",
                value: data.price,
                onChange: (e) => setData("price", e.target.value),
                required: true
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "my-3", children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "discount",
                value: "Product Discount"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "discount",
                name: "discount",
                value: data.discount,
                onChange: (e) => setData("discount", e.target.value),
                required: true
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { className: "my-3 flex justify-end", children: /* @__PURE__ */ jsx(PrimaryButton, { className: "py-3 px-8", children: "Update Product" }) })
        ] }) : /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 py-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex sm:items-center sm:justify-center w-full", children: [
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: () => {
                  if (data.quantity > 1) {
                    setData("quantity", data.quantity - 1);
                  }
                },
                className: "group py-4 px-6 border border-indigo-600 rounded-l-full bg-transparent transition-all duration-300 hover:bg-indigo-600 hover:text-white",
                children: "-"
              }
            ),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                className: "font-semibold cursor-pointer text-lg py-[13px] px-6 w-full sm:max-w-[118px] outline-0 border-y border-indigo-600 bg-transparent placeholder: text-center hover:bg-indigo-600 hover:text-white transition-all duration-300",
                value: data.quantity,
                readOnly: true
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: () => setData("quantity", data.quantity + 1),
                className: "group py-4 px-6 border border-indigo-600 rounded-r-full transition-all duration-300 hover:bg-indigo-600 hover:text-white",
                children: "+"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: submit,
              className: "group py-4 px-5 rounded-full text-white bg-indigo-950 font-semibold text-lg w-full flex items-center justify-center gap-2 transition-all duration-500 hover:bg-indigo-600 hover:text-white",
              children: [
                /* @__PURE__ */ jsx(ShoppingCartIcon, { className: "h-6 w-6" }),
                "Add to cart"
              ]
            }
          )
        ] })
      ] }) })
    ] }) }) }) })
  ] });
}
export {
  View as default
};
