import { jsx, jsxs } from "react/jsx-runtime";
import { useRef, useState, useEffect } from "react";
import { A as ApplicationLogo, D as DarkModeSwitcher, N as NavLink } from "./NavLink-DTY072R5.js";
import { Link } from "@inertiajs/react";
import { HomeIcon, WrenchScrewdriverIcon, UserIcon, LockClosedIcon } from "@heroicons/react/24/solid";
import { QueueListIcon, ShoppingCartIcon } from "@heroicons/react/24/outline";
const Header = (props) => {
  var _a, _b;
  return /* @__PURE__ */ jsx("header", { className: "sticky top-0 z-999 flex w-full bg-white drop-shadow-1 dark:bg-boxdark dark:drop-shadow-none", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-grow items-center justify-between px-4 py-4 shadow-2 md:px-6 2xl:px-11", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 sm:gap-4 lg:hidden", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          "aria-controls": "sidebar",
          onClick: (e) => {
            e.stopPropagation();
            props.setSidebarOpen(!props.sidebarOpen);
          },
          className: "z-99999 block rounded-sm border border-stroke bg-white p-1.5 shadow-sm dark:border-strokedark dark:bg-boxdark lg:hidden",
          children: /* @__PURE__ */ jsxs("span", { className: "relative block h-5.5 w-5.5 cursor-pointer", children: [
            /* @__PURE__ */ jsxs("span", { className: "du-block absolute right-0 h-full w-full", children: [
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: `relative left-0 top-0 my-1 block h-0.5 w-0 rounded-sm bg-black delay-[0] duration-200 ease-in-out dark:bg-white ${!props.sidebarOpen && "!w-full delay-300"}`
                }
              ),
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: `relative left-0 top-0 my-1 block h-0.5 w-0 rounded-sm bg-black delay-150 duration-200 ease-in-out dark:bg-white ${!props.sidebarOpen && "delay-400 !w-full"}`
                }
              ),
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: `relative left-0 top-0 my-1 block h-0.5 w-0 rounded-sm bg-black delay-200 duration-200 ease-in-out dark:bg-white ${!props.sidebarOpen && "!w-full delay-500"}`
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("span", { className: "absolute right-0 h-full w-full rotate-45", children: [
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: `absolute left-2.5 top-0 block h-full w-0.5 rounded-sm bg-black delay-300 duration-200 ease-in-out dark:bg-white ${!props.sidebarOpen && "!h-0 !delay-[0]"}`
                }
              ),
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: `delay-400 absolute left-0 top-2.5 block h-0.5 w-full rounded-sm bg-black duration-200 ease-in-out dark:bg-white ${!props.sidebarOpen && "!h-0 !delay-200"}`
                }
              )
            ] })
          ] })
        }
      ),
      /* @__PURE__ */ jsx(Link, { className: "block flex-shrink-0 lg:hidden", href: "/", children: /* @__PURE__ */ jsx(ApplicationLogo, {}) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "hidden sm:block", children: /* @__PURE__ */ jsx("form", { action: "https://formbold.com/s/unique_form_id", method: "POST", children: /* @__PURE__ */ jsxs("div", { className: "relative", children: [
      /* @__PURE__ */ jsx("button", { className: "absolute left-0 top-1/2 -translate-y-1/2", children: /* @__PURE__ */ jsxs(
        "svg",
        {
          className: "fill-body hover:fill-primary dark:fill-bodydark dark:hover:fill-primary",
          width: "20",
          height: "20",
          viewBox: "0 0 20 20",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          children: [
            /* @__PURE__ */ jsx(
              "path",
              {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M9.16666 3.33332C5.945 3.33332 3.33332 5.945 3.33332 9.16666C3.33332 12.3883 5.945 15 9.16666 15C12.3883 15 15 12.3883 15 9.16666C15 5.945 12.3883 3.33332 9.16666 3.33332ZM1.66666 9.16666C1.66666 5.02452 5.02452 1.66666 9.16666 1.66666C13.3088 1.66666 16.6667 5.02452 16.6667 9.16666C16.6667 13.3088 13.3088 16.6667 9.16666 16.6667C5.02452 16.6667 1.66666 13.3088 1.66666 9.16666Z",
                fill: ""
              }
            ),
            /* @__PURE__ */ jsx(
              "path",
              {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M13.2857 13.2857C13.6112 12.9603 14.1388 12.9603 14.4642 13.2857L18.0892 16.9107C18.4147 17.2362 18.4147 17.7638 18.0892 18.0892C17.7638 18.4147 17.2362 18.4147 16.9107 18.0892L13.2857 14.4642C12.9603 14.1388 12.9603 13.6112 13.2857 13.2857Z",
                fill: ""
              }
            )
          ]
        }
      ) }),
      /* @__PURE__ */ jsx(
        "input",
        {
          type: "text",
          placeholder: "Type to search...",
          className: "w-full bg-transparent pl-9 pr-4 text-black focus:outline-none dark:text-white xl:w-125"
        }
      )
    ] }) }) }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 2xsm:gap-7", children: [
      /* @__PURE__ */ jsx("ul", { className: "flex items-center gap-2 2xsm:gap-4", children: /* @__PURE__ */ jsx(DarkModeSwitcher, {}) }),
      /* @__PURE__ */ jsxs("span", { className: "hidden text-right lg:block", children: [
        /* @__PURE__ */ jsx("span", { className: "block text-sm font-medium uppercase text-black dark:text-white", children: (_a = props.user) == null ? void 0 : _a.name }),
        /* @__PURE__ */ jsx("span", { className: "block text-xs lowercase", children: (_b = props.user) == null ? void 0 : _b.email })
      ] })
    ] })
  ] }) });
};
const Sidebar = ({ sidebarOpen, setSidebarOpen }) => {
  const trigger = useRef(null);
  const sidebar = useRef(null);
  const storedSidebarExpanded = localStorage.getItem("sidebar-expanded");
  const [sidebarExpanded, setSidebarExpanded] = useState(
    storedSidebarExpanded === null ? false : storedSidebarExpanded === "true"
  );
  useEffect(() => {
    const clickHandler = ({ target }) => {
      if (!sidebar.current || !trigger.current) return;
      if (!sidebarOpen || sidebar.current.contains(target) || trigger.current.contains(target))
        return;
      setSidebarOpen(false);
    };
    document.addEventListener("click", clickHandler);
    return () => document.removeEventListener("click", clickHandler);
  });
  useEffect(() => {
    const keyHandler = ({ keyCode }) => {
      if (!sidebarOpen || keyCode !== 27) return;
      setSidebarOpen(false);
    };
    document.addEventListener("keydown", keyHandler);
    return () => document.removeEventListener("keydown", keyHandler);
  });
  useEffect(() => {
    var _a, _b;
    localStorage.setItem("sidebar-expanded", sidebarExpanded.toString());
    if (sidebarExpanded) {
      (_a = document.querySelector("body")) == null ? void 0 : _a.classList.add("sidebar-expanded");
    } else {
      (_b = document.querySelector("body")) == null ? void 0 : _b.classList.remove("sidebar-expanded");
    }
  }, [sidebarExpanded]);
  return /* @__PURE__ */ jsxs(
    "aside",
    {
      ref: sidebar,
      className: `absolute left-0 top-0 z-9999 flex h-screen w-72.5 flex-col overflow-y-hidden bg-white duration-300 ease-linear dark:bg-boxdark lg:static lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`,
      children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2 px-6 py-5.5 lg:py-6.5", children: [
          /* @__PURE__ */ jsx(NavLink, { active: false, href: route("dashboard"), children: /* @__PURE__ */ jsx(ApplicationLogo, {}) }),
          /* @__PURE__ */ jsx(
            "button",
            {
              ref: trigger,
              onClick: () => setSidebarOpen(!sidebarOpen),
              "aria-controls": "sidebar",
              "aria-expanded": sidebarOpen,
              className: "block lg:hidden",
              children: /* @__PURE__ */ jsx(
                "svg",
                {
                  className: "fill-current",
                  width: "20",
                  height: "18",
                  viewBox: "0 0 20 18",
                  fill: "none",
                  xmlns: "http://www.w3.org/2000/svg",
                  children: /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M19 8.175H2.98748L9.36248 1.6875C9.69998 1.35 9.69998 0.825 9.36248 0.4875C9.02498 0.15 8.49998 0.15 8.16248 0.4875L0.399976 8.3625C0.0624756 8.7 0.0624756 9.225 0.399976 9.5625L8.16248 17.4375C8.31248 17.5875 8.53748 17.7 8.76248 17.7C8.98748 17.7 9.17498 17.625 9.36248 17.475C9.69998 17.1375 9.69998 16.6125 9.36248 16.275L3.02498 9.8625H19C19.45 9.8625 19.825 9.4875 19.825 9.0375C19.825 8.55 19.45 8.175 19 8.175Z",
                      fill: ""
                    }
                  )
                }
              )
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "no-scrollbar flex flex-col overflow-y-auto duration-300 ease-linear", children: /* @__PURE__ */ jsx("nav", { className: "mt-5 py-4 px-4 lg:mt-9 lg:px-6", children: /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h3", { className: "mb-4 ml-4 text-sm font-semibold text-bodydark2", children: "MENU" }),
          /* @__PURE__ */ jsxs("ul", { className: "mb-6 flex flex-col gap-1.5", children: [
            /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                active: route().current("dashboard"),
                href: route("dashboard"),
                children: [
                  /* @__PURE__ */ jsx(HomeIcon, { className: "fill-current h-5 w-5" }),
                  "Dashboard"
                ]
              }
            ) }),
            /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                active: route().current("categories"),
                href: route("categories"),
                children: [
                  /* @__PURE__ */ jsx(QueueListIcon, { className: "fill-current h-5 w-5" }),
                  "Categories"
                ]
              }
            ) }),
            /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                active: route().current("product_types"),
                href: route("product_types"),
                children: [
                  /* @__PURE__ */ jsx(WrenchScrewdriverIcon, { className: "fill-current h-5 w-5" }),
                  "Product Types"
                ]
              }
            ) }),
            /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                active: route().current("products"),
                href: route("products"),
                children: [
                  /* @__PURE__ */ jsx(WrenchScrewdriverIcon, { className: "fill-current h-5 w-5" }),
                  "Products"
                ]
              }
            ) }),
            /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                active: route().current("orders"),
                href: route("orders"),
                children: [
                  /* @__PURE__ */ jsx(ShoppingCartIcon, { className: "fill-current h-5 w-5" }),
                  "Orders"
                ]
              }
            ) }),
            /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                active: route().current("profile.edit"),
                href: route("profile.edit"),
                children: [
                  /* @__PURE__ */ jsx(UserIcon, { className: "fill-current h-5 w-5" }),
                  "Profile"
                ]
              }
            ) }),
            /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                active: route().current("logout"),
                href: route("logout"),
                as: "button",
                method: "post",
                children: [
                  /* @__PURE__ */ jsx(LockClosedIcon, { className: "fill-current h-5 w-5" }),
                  "Logout"
                ]
              }
            ) })
          ] })
        ] }) }) })
      ]
    }
  );
};
const formatDate = (dateString) => {
  return new Date(dateString).toLocaleString("default", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "numeric"
  });
};
const AdminLayout = ({
  user,
  children
}) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  return /* @__PURE__ */ jsx("div", { className: "dark:bg-boxdark-2 dark:text-bodydark", children: /* @__PURE__ */ jsxs("div", { className: "flex h-screen overflow-hidden", children: [
    /* @__PURE__ */ jsx(Sidebar, { sidebarOpen, setSidebarOpen }),
    /* @__PURE__ */ jsxs("div", { className: "relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden", children: [
      /* @__PURE__ */ jsx(
        Header,
        {
          user,
          sidebarOpen,
          setSidebarOpen
        }
      ),
      /* @__PURE__ */ jsx("main", { children: /* @__PURE__ */ jsx("div", { className: "mx-auto py-6 md:p-6 2xl:p-10", children }) })
    ] })
  ] }) });
};
export {
  AdminLayout as A,
  formatDate as f
};
