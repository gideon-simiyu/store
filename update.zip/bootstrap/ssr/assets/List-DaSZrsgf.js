import { jsxs, jsx } from "react/jsx-runtime";
import { M as Modal } from "./Modal-BunpyNFw.js";
import { P as PrimaryButton } from "./PrimaryButton-namq1TfZ.js";
import { A as AdminLayout, f as formatDate } from "./AdminLayout-BLojdTCi.js";
import { useForm, Link } from "@inertiajs/react";
import { useState } from "react";
import "@headlessui/react";
import "framer-motion";
import "./NavLink-DTY072R5.js";
import "@heroicons/react/24/solid";
import "@heroicons/react/24/outline";
function List({ auth, product_types = [] }) {
  const [showModal, setShowModal] = useState(false);
  const { data, setData, post, reset, errors } = useForm({
    name: "",
    description: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("product_types.create"), {
      preserveScroll: true,
      onSuccess: () => {
        reset();
        setShowModal(false);
      }
    });
  };
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteProductType, setDeleteProductType] = useState(null);
  const toggleDeleteModal = (productType) => {
    setDeleteProductType(productType);
    setShowDeleteModal(true);
  };
  return /* @__PURE__ */ jsxs(AdminLayout, { user: auth.user, children: [
    /* @__PURE__ */ jsxs("div", { className: "rounded-sm bg-white py-6 px-3 md:px-7.5 shadow-default dark:bg-boxdark", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-title-md font-bold text-black dark:text-white", children: "Product Types" }),
        /* @__PURE__ */ jsx(PrimaryButton, { onClick: () => setShowModal(true), children: "Create product Type" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "max-w-full overflow-x-auto mt-4", children: /* @__PURE__ */ jsxs("table", { className: "w-full table-auto", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-gray-2 text-left dark:bg-meta-4", children: [
          /* @__PURE__ */ jsx("th", { className: "min-w-[220px] py-4 px-4 font-medium text-black dark:text-white xl:pl-11", children: "Name" }),
          /* @__PURE__ */ jsx("th", { className: "min-w-[150px] py-4 px-4 font-medium text-black dark:text-white", children: "Description" }),
          /* @__PURE__ */ jsx("th", { className: "min-w-[120px] py-4 px-4 font-medium text-black dark:text-white", children: "Created On" }),
          /* @__PURE__ */ jsx("th", { className: "py-4 px-4 font-medium text-black dark:text-white", children: "Updated On" }),
          /* @__PURE__ */ jsx("th", { className: "py-4 px-4 font-medium text-black dark:text-white", children: "Actions" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: product_types.map((productType, index) => /* @__PURE__ */ jsxs(
          "tr",
          {
            className: `${index % 2 === 0 ? "bg-grey-100 dark:bg-grey-900" : "bg-grey-200 dark:bg-grey-800"}`,
            children: [
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("h5", { className: "font-medium text-black dark:text-white", children: productType.name }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: productType.description }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: formatDate(productType.created_at) }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsx("p", { className: "text-black dark:text-white", children: formatDate(productType.updated_at) }) }),
              /* @__PURE__ */ jsx("td", { className: "border-b border-[#eee] py-5 px-4 dark:border-strokedark", children: /* @__PURE__ */ jsxs("p", { className: "text-black dark:text-white flex gap-5", children: [
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: `/admin/product-types/${productType.id}/edit`,
                    className: "text-blue-600 dark:text-blue-400",
                    children: "View"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "span",
                  {
                    className: "text-red-600 dark:text-red-400 cursor-pointer",
                    onClick: () => toggleDeleteModal(productType),
                    children: "Delete"
                  }
                )
              ] }) })
            ]
          },
          index
        )) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsx(Modal, { onClose: () => setShowModal(false), show: showModal, children: /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "p-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "name", className: "form-label", children: "ProductType Name" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            name: "name",
            id: "name",
            value: data.name,
            onChange: (e) => setData("name", e.target.value),
            className: "form-input"
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.name })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "name", className: "form-label", children: "ProductType Description" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            name: "description",
            id: "description",
            value: data.description,
            onChange: (e) => setData("description", e.target.value),
            className: "form-input"
          }
        ),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-red-500", children: errors.description })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsx(PrimaryButton, { type: "submit", children: "Create Product Type" }) })
    ] }) }),
    /* @__PURE__ */ jsx(Modal, { onClose: () => setShowDeleteModal(false), show: showDeleteModal, children: /* @__PURE__ */ jsx("div", { className: "p-3", children: /* @__PURE__ */ jsxs("p", { className: "text-white", children: [
      'Are you sure you want to delete product type "',
      deleteProductType == null ? void 0 : deleteProductType.name,
      '"'
    ] }) }) })
  ] });
}
export {
  List as default
};
