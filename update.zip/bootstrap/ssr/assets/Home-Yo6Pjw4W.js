import { jsxs, jsx } from "react/jsx-runtime";
import { P as ProductDisplay } from "./ProductDisplay-CzMIaf_Z.js";
import { A as Authenticated } from "./AuthenticatedLayout-B0RmSo8o.js";
import { G as Guest } from "./GuestLayout-CF0LXAnb.js";
import { Link, Head } from "@inertiajs/react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRightIcon } from "@heroicons/react/24/outline";
import { useState, useEffect } from "react";
import { ArrowLeftIcon } from "@heroicons/react/24/solid";
import "@heroicons/react/20/solid";
import "./NavLink-DTY072R5.js";
import "./Harmbuger-DjbFdboI.js";
const bannerImage1 = "/build/assets/banner-image-3-4U1Lrj2f.png";
const bannerImage2 = "/build/assets/banner-image-2-BxpsuUM1.png";
const bannerImage3 = "/build/assets/banner-image-1-Cg3RaCKb.png";
function ShopButton({ href, children }) {
  return /* @__PURE__ */ jsxs(
    Link,
    {
      href: route("shop"),
      className: "flex px-8 py-4 text-xl justify-center gap-2 items-center w-fit shadow-xl uppercase bg-transparent backdrop-blur-md lg:font-semibold isolation-auto before:absolute before:w-full before:transition-all before:duration-700 before:hover:w-full before:-left-full before:hover:left-0 before:rounded-full before:bg-indigo-600 hover:text-grey-50 before:-z-10 before:aspect-square before:hover:scale-150 before:hover:duration-700 relative z-10 overflow-hidden border-2 rounded-full group",
      children: [
        "shop now",
        /* @__PURE__ */ jsx(
          "svg",
          {
            className: "w-8 h-8 justify-end group-hover:rotate-90 group-hover:bg-grey-50 text-grey-50 ease-linear duration-300 rounded-full border group-hover:border-none p-2 rotate-45",
            viewBox: "0 0 16 19",
            xmlns: "http://www.w3.org/2000/svg",
            children: /* @__PURE__ */ jsx(
              "path",
              {
                d: "M7 18C7 18.5523 7.44772 19 8 19C8.55228 19 9 18.5523 9 18H7ZM8.70711 0.292893C8.31658 -0.0976311 7.68342 -0.0976311 7.29289 0.292893L0.928932 6.65685C0.538408 7.04738 0.538408 7.68054 0.928932 8.07107C1.31946 8.46159 1.95262 8.46159 2.34315 8.07107L8 2.41421L13.6569 8.07107C14.0474 8.46159 14.6805 8.46159 15.0711 8.07107C15.4616 7.68054 15.4616 7.04738 15.0711 6.65685L8.70711 0.292893ZM9 18L9 1H7L7 18H9Z",
                className: "fill-grey-800 dark:fill-grey-100 group-hover:fill-grey-800"
              }
            )
          }
        )
      ]
    }
  );
}
function Home({ auth, categories = [], products = [] }) {
  if (auth.user) {
    return /* @__PURE__ */ jsx(Authenticated, { user: auth.user, children: /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
      HomeComponent,
      {
        auth,
        categories,
        products
      }
    ) }) });
  }
  return /* @__PURE__ */ jsx(Guest, { auth: false, children: /* @__PURE__ */ jsx("div", { className: "", children: /* @__PURE__ */ jsx(
    HomeComponent,
    {
      auth,
      categories,
      products
    }
  ) }) });
}
const HomeComponent = ({ auth, categories, products }) => {
  const images = [bannerImage1, bannerImage2, bannerImage3];
  const [imageIndex, setImageIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const imageCount = images.length;
  useEffect(() => {
    const interval = setInterval(() => {
      handleNext();
    }, 3e3);
    return () => clearInterval(interval);
  }, [imageIndex]);
  const handleNext = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setImageIndex((prevIndex) => (prevIndex + 1) % imageCount);
  };
  const handlePrev = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setImageIndex(
      (prevIndex) => prevIndex === 0 ? imageCount - 1 : prevIndex - 1
    );
  };
  const variants = {
    enter: (direction) => ({
      x: direction > 0 ? 1e3 : -1e3,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1,
      transition: { duration: 0.8, ease: "easeOut" }
    },
    exit: (direction) => ({
      x: direction < 0 ? 1e3 : -1e3,
      opacity: 0,
      transition: { duration: 0.8, ease: "easeIn" }
    })
  };
  const titleVariants = {
    hidden: { opacity: 0, y: -50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" }
    }
  };
  const subtitleVariants = {
    hidden: { opacity: 0, x: -30 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { delay: 0.3, duration: 0.8, ease: "easeOut" }
    }
  };
  const descriptionVariants = {
    hidden: { opacity: 0, x: 30 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { delay: 0.6, duration: 0.8, ease: "easeOut" }
    }
  };
  return /* @__PURE__ */ jsxs(motion.div, { initial: "hidden", animate: "visible", children: [
    /* @__PURE__ */ jsx(Head, { title: "Home" }),
    /* @__PURE__ */ jsxs("div", { className: "relative min-h-171.5 -m-6 -mx-8 flex flex-col justify-center bg-indigo-200 dark:bg-indigo-950 overflow-hidden", children: [
      /* @__PURE__ */ jsx(AnimatePresence, { initial: false, custom: imageIndex, children: images.map(
        (image, index) => index === imageIndex && /* @__PURE__ */ jsxs(
          motion.div,
          {
            custom: index,
            initial: "enter",
            animate: "center",
            exit: "exit",
            variants,
            onAnimationComplete: () => setIsAnimating(false),
            className: "absolute w-full h-full p-5 flex gap-10 justify-center items-center",
            children: [
              /* @__PURE__ */ jsxs(
                motion.div,
                {
                  className: "flex absolute lg:relative bg-indigo-800 w-screen bg-opacity-20 text-center p-4 lg:text-start lg:w-full lg:bg-inherit flex-col gap-7 h-full justify-center basis-1/3",
                  initial: { opacity: 0 },
                  animate: { opacity: 1 },
                  transition: { duration: 0.8 },
                  children: [
                    /* @__PURE__ */ jsxs(
                      motion.h1,
                      {
                        className: "text-7xl font-bold",
                        variants: titleVariants,
                        initial: "hidden",
                        animate: "visible",
                        children: [
                          "Up To ",
                          /* @__PURE__ */ jsx("br", {}),
                          /* @__PURE__ */ jsx("span", { className: "text-indigo-600 me-2", children: "30%" }),
                          "Discount"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxs(
                      motion.p,
                      {
                        className: "text-5xl",
                        variants: subtitleVariants,
                        initial: "hidden",
                        animate: "visible",
                        children: [
                          (/* @__PURE__ */ new Date()).getFullYear(),
                          " ",
                          "Collection"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      motion.p,
                      {
                        className: "text-3xl",
                        variants: descriptionVariants,
                        initial: "hidden",
                        animate: "visible",
                        children: "New Modern Stylish Fashionable Women, Men, and Kids Wear"
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      motion.div,
                      {
                        className: "flex w-full justify-center lg:justify-start",
                        initial: { opacity: 0 },
                        animate: { opacity: 1 },
                        transition: {
                          delay: 0.9,
                          duration: 1
                        },
                        children: /* @__PURE__ */ jsx(ShopButton, {})
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ jsx(
                motion.img,
                {
                  src: image,
                  alt: "",
                  className: "h-full w-auto object-cover"
                }
              )
            ]
          },
          index
        )
      ) }),
      /* @__PURE__ */ jsxs("div", { className: "absolute bottom-10 right-10 flex gap-4", children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: handlePrev,
            className: "bg-indigo-600 text-white rounded-full p-2",
            children: /* @__PURE__ */ jsx(ArrowLeftIcon, { className: "h-6 w-6" })
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: handleNext,
            className: "bg-indigo-600 text-white rounded-full p-2",
            children: /* @__PURE__ */ jsx(ArrowRightIcon, { className: "h-6 w-6" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: " basis-12/12 lg:basis-10/12 xl:basis-9/12 mx-auto", children: [
      /* @__PURE__ */ jsx("section", { id: "categories", className: "py-16", children: /* @__PURE__ */ jsxs("div", { className: "container mx-auto px-4", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-3xl font-bold text-center mb-12", children: "Shop By Category" }),
        /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8", children: categories.map((category, index) => {
          var _a;
          return /* @__PURE__ */ jsxs(
            "div",
            {
              className: "group max-w-sm bg-grey-200 relative overflow-hidden shadow-lg rounded-full h-70 w-70 border-2 dark:border-8 border-indigo-600",
              children: [
                /* @__PURE__ */ jsx(
                  "img",
                  {
                    src: `/storage/${(_a = category.products[0]) == null ? void 0 : _a.image}`,
                    alt: category.name,
                    className: "w-full h-full object-fill bg-white transition duration-300 group-hover:scale-105"
                  }
                ),
                /* @__PURE__ */ jsx("div", { className: "absolute bg-slate-900 inset-0 bg-opacity-75 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300", children: /* @__PURE__ */ jsx("h3", { className: "text-white text-2xl font-bold uppercase", children: category.name }) })
              ]
            },
            index
          );
        }) })
      ] }) }),
      /* @__PURE__ */ jsx(
        "section",
        {
          id: "featured-products",
          className: "py-16 bg-indigo-200 dark:bg-indigo-950 -mx-8",
          children: /* @__PURE__ */ jsxs("div", { className: "container mx-auto px-4", children: [
            /* @__PURE__ */ jsx("h2", { className: "text-3xl font-bold text-center mb-12", children: "Featured Products" }),
            /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 overflow-x-auto", children: products.map((product, index) => /* @__PURE__ */ jsx(
              "div",
              {
                className: "group relative overflow-hidden rounded-lg",
                children: /* @__PURE__ */ jsx(
                  ProductDisplay,
                  {
                    auth,
                    product
                  }
                )
              },
              index
            )) })
          ] })
        }
      )
    ] })
  ] });
};
export {
  Home as default
};
