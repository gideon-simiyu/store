import { usePage } from "@inertiajs/react";

export default function Messaging() {
  const { props } = usePage();
  const { flash } = props;
  
  return(
  )
}
