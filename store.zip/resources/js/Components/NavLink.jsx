import { Link } from '@inertiajs/react';
import { motion } from 'framer-motion';

export default function NavLink({ active = false , route, children, ...props}) {
  const class_name = active ? "bg-indigo-600 text-white hover:bg-indigo-500" : "text-black dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400";
  return(
    <motion.li
      initial={{ scale: 0, x:100 }}
      animate={{ scale: 1, x:0,  transition: { duration: 0.3 } }}
      exit={{ scale: 0 }}
      
      className={`w-full h-full ${class_name} flex justify-start items-center rounded-md border border-transparent`}>
      <Link
        href={route}
        class="py-1.5 flex px-3 transition-all duration-300 ease-in-out text-lg font-medium rounded-md"
        {...props}
      >
        {children}
      </Link>
      </motion.li>
  )
    return (
        <Link
            {...props}
            className={
                'inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium leading-5 transition duration-150 ease-in-out focus:outline-none ' +
                (active
                    ? 'border-indigo-700 dark:border-indigo-400 text-indigo-700 dark:text-indigo-400 focus:border-indigo-700 '
                    : 'border-transparent text-gray-800 dark:text-gray-100 hover:border-indigo-700 dark:hover:border-indigo-400 focus:text-indigo-700 dark:focus:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-400 ') +
                className
            }
        >
            {children}
        </Link>
    );
}
