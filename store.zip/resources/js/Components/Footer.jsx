import ApplicationLogo from "@/Components/ApplicationLogo";
import { Link } from "@inertiajs/react";

export default function Footer() {
  return (
    <footer class="w-full py-2 bg-primary text-gray-800 dark:text-gray-200 shadow-lg">
      <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="max-w-3xl mx-auto">          
          <span class="text-lg text-center block">
            ©<Link href={route("home")}> Threads & Trends</Link> 2024, All rights
            reserved.
          </span>
        </div>
      </div>
    </footer>
  );
}
