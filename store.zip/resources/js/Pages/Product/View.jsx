import {
  BreadCrumbIcon,
  CartIcon,
  HeartIcon,
  StarRatingIcon,
} from "@/Components/Icons";
import Authenticated from "@/Layouts/AuthenticatedLayout";
import { Link, useForm } from "@inertiajs/react";
import { Fragment } from "react";

export default function View({ auth, product, sizes = [] }) {
  const rating = parseInt(product.rating.toString());
  const unrated = 5 - rating;

  const { data, setData, post, processing, errors, reset } = useForm({
    product_id: product.id,
    size: "",
    quantity: 1,
  });

  const submit = (e) => {
    e.preventDefault();

    post(route("cart.add"), {
      onFinish: () => reset("quantity"),
    });
  };

  return (
    <Authenticated
      user={auth.user}
      header={
        <div className="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight flex space-x-2">
          <Link className="breadcrumb-link" href={route("home")}>
            Home
          </Link>
          <BreadCrumbIcon />
          <Link className="breadcrumb-link" href={route("products")}>
            Products
          </Link>{" "}
          <BreadCrumbIcon />
          <span>{product.name}</span>
        </div>
      }
    >
      <div className="container flex justify-center mx-auto">
        <section class="relative max-w-fit">
          <div class="w-full mx-auto px-4 sm:px-6 lg:px-0">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 mx-auto max-md:px-2 ">
              <div class="img">
                <div class="h-full max-lg:mx-auto rounded-xl bg-gray-300 dark:bg-gray-800 p-2">
                  <img
                    src={`/storage/${product.image}`}
                    alt={product.name}
                    class="max-lg:mx-auto lg:ml-auto h-full rounded-lg"
                  />
                </div>
              </div>
              <div class="data w-full lg:pr-8 pr-0 xl:justify-start justify-center flex items-start max-lg:pb-10 xl:my-2 lg:my-5 my-0">
                <div class="data w-full max-w-xl">
                  <p class="text-lg font-medium leading-8 text-indigo-600 mb-4">
                    <span className="capitalize">{product.category.name}</span>
                    &nbsp; /&nbsp;{" "}
                    <span className="capitalize">
                      {product.product_type.name}
                    </span>
                  </p>
                  <h2 class="font-manrope font-bold text-3xl leading-10 mb-2 capitalize">
                    {product.name}
                  </h2>
                  <div class="flex flex-col sm:flex-row sm:items-center mb-6">
                    <h6 class="font-manrope font-semibold text-2xl leading-9 pr-5 sm:border-r border-gray-200 mr-5">
                      $220
                    </h6>
                    <div class="flex items-center gap-2">
                      <div class="flex items-center gap-1">
                        {[...Array(rating)].map((_, index) => (
                          <StarRatingIcon key={index} index={index} />
                        ))}
                        {[...Array(unrated)].map((_, index) => (
                          <StarRatingIcon
                            key={index}
                            index={index}
                            className="h-6 w-6 text-gray-300"
                          />
                        ))}
                      </div>
                      <span class="pl-2 font-normal leading-7 text-sm ">
                        1624 review
                      </span>
                    </div>
                  </div>
                  <p class="text-base font-normal mb-5">
                    Introducing our vibrant Basic Yellow Tropical Printed Shirt
                    - a celebration of style and sunshine! Embrace the essence
                    of summer wherever you go with this eye-catching piece that
                    effortlessly blends comfort and tropical flair.
                  </p>

                  {sizes.length > 0 && (
                    <Fragment>
                      <p class=" text-lg leading-8 font-medium mb-4">Size</p>
                      <div class="w-full pb-8 border-b border-gray-100 flex-wrap">
                        <div class="grid grid-cols-3 min-[400px]:grid-cols-5 gap-3 max-w-md">
                          {sizes.map((size) => (
                            <button class="text-center py-1.5 px-6 w-full font-semibold text-lg leading-8 border border-indigo-600 flex items-center rounded-full justify-center transition-all duration-300 hover:bg-indigo-600 hover:text-white">
                              S
                            </button>
                          ))}
                        </div>
                      </div>
                    </Fragment>
                  )}
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 py-8">
                    <div class="flex sm:items-center sm:justify-center w-full">
                      <button
                        onClick={() => {
                          if (data.quantity > 1) {
                            setData("quantity", data.quantity - 1);
                          }
                        }}
                        class="group py-4 px-6 border border-indigo-600 rounded-l-full bg-transparent transition-all duration-300 hover:bg-indigo-600 hover:text-white"
                      >
                        -
                      </button>
                      <input
                        type="text"
                        class="font-semibold cursor-pointer text-lg py-[13px] px-6 w-full sm:max-w-[118px] outline-0 border-y border-indigo-600 bg-transparent placeholder: text-center hover:bg-indigo-600 hover:text-white transition-all duration-300"
                        value={data.quantity}
                        readOnly
                      />
                      <button
                        onClick={() => setData("quantity", data.quantity + 1)}
                        class="group py-4 px-6 border border-indigo-600 rounded-r-full transition-all duration-300 hover:bg-indigo-600 hover:text-white"
                      >
                        +
                      </button>
                    </div>
                    <button
                      onClick={submit}
                      class="group py-4 px-5 rounded-full text-white bg-indigo-950 font-semibold text-lg w-full flex items-center justify-center gap-2 transition-all duration-500 hover:bg-indigo-600 hover:text-white"
                    >
                      <CartIcon />
                      Add to cart
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </Authenticated>
  );
}
