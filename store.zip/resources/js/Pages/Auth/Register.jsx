import GuestLayout from "@/Layouts/GuestLayout";
import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import PrimaryButton from "@/Components/PrimaryButton";
import TextInput from "@/Components/TextInput";
import { Head, Link, useForm } from "@inertiajs/react";
import ApplicationLogo from "@/Components/ApplicationLogo";

export default function Register() {
  const { data, setData, post, processing, errors, reset } = useForm({
    name: "",
    email: "",
    password: "",
    password_confirmation: "",
  });

  const submit = (e) => {
    e.preventDefault();

    post(route("register"), {
      onFinish: () => reset("password", "password_confirmation"),
    });
  };

  return (
    <GuestLayout>
      <Head title="Create Account" />
      <form class="lg:p-11 p-7 mx-auto" onSubmit={submit}>
        <div className="flex justify-center w-full">
          <ApplicationLogo className="mx-auto lg:mb-11 mb-8" />
        </div>
        <div class="mb-4">
          <h1 class="text-center font-manrope text-3xl font-bold leading-10 mb-2">
            Welcome Back
          </h1>
          <p class="text-indigo-500 text-center text-base font-medium leading-6">
            Log in to your account to continue
          </p>
        </div>

        <TextInput
          id="name"
          name="name"
          value={data.name}
          className="mt-1 block w-full"
          autoComplete="name"
          isFocused={true}
          onChange={(e) => setData("name", e.target.value)}
          placeholder="Your Name"
          required
        />

        <InputError message={errors.name} className="mt-2" />
        <TextInput
          id="email"
          type="email"
          name="email"
          value={data.email}
          className="text-input"
          autoComplete="username"
          isFocused={true}
          placeholder="Email"
          onChange={(e) => setData("email", e.target.value)}
        />
        <InputError message={errors.email} className="mt-2" />
        <TextInput
          id="password"
          type="password"
          name="password"
          value={data.password}
          className="text-input"
          autoComplete="current-password"
          onChange={(e) => setData("password", e.target.value)}
          placeholder="Password"
        />
        <InputError message={errors.password} className="mt-2" />

        <TextInput
          id="password_confirmation"
          type="password"
          name="password_confirmation"
          value={data.password_confirmation}
          className="mt-1 block w-full"
          autoComplete="new-password"
          onChange={(e) => setData("password_confirmation", e.target.value)}
          placeholder="Confirm Password"
          required
        />

        <InputError message={errors.password_confirmation} className="mt-2" />
        <button class="w-full mt-6 h-12 text-white text-center text-base font-semibold leading-6 rounded-full hover:bg-indigo-800 transition-all duration-700 bg-indigo-600 shadow-sm mb-11">
          Login
        </button>
        <Link
          href={route("login")}
          className="flex justify-center text-base font-medium leading-6"
        >
          ALready have an account?
          <span class="text-indigo-500 font-semibold pl-3"> Sign In</span>
        </Link>
      </form>
    </GuestLayout>
  );
}
