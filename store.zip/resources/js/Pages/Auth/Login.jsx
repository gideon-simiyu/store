import Checkbox from "@/Components/Checkbox";
import GuestLayout from "@/Layouts/GuestLayout";
import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import PrimaryButton from "@/Components/PrimaryButton";
import TextInput from "@/Components/TextInput";
import { Head, Link, useForm } from "@inertiajs/react";
import { useState } from "react";
import ApplicationLogo from "@/Components/ApplicationLogo";

export default function Login({ status, canResetPassword }) {
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
  });

  const [passwordShown, setPasswordShown] = useState(false);
  const togglePasswordVisiblity = () => {
    setPasswordShown(passwordShown ? false : true);
  };

  const submit = (e) => {
    e.preventDefault();

    post(route("login"), {
      onFinish: () => reset("password"),
    });
  };
  return (
    <GuestLayout>
      <Head title="Log in" />

      {status && (
        <div className="mb-4 font-medium text-green-600">{status}</div>
      )}
      <form class="lg:p-11 p-7 mx-auto" onSubmit={submit}>
        <div className="flex justify-center w-full">
          <ApplicationLogo className="mx-auto lg:mb-11 mb-8" />
        </div>
        <div class="mb-4">
          <h1 class="text-center font-manrope text-3xl font-bold leading-10 mb-2">
            Welcome Back
          </h1>
          <p class="text-indigo-500 text-center text-base font-medium leading-6">
            Log in to your account to continue
          </p>
        </div>
        <TextInput
          id="email"
          type="email"
          name="email"
          value={data.email}
          className="text-input"
          autoComplete="username"
          isFocused={true}
          placeholder="Email"
          onChange={(e) => setData("email", e.target.value)}
        />
        <InputError message={errors.email} className="mt-2" />
        <TextInput
          id="password"
          type={passwordShown ? "text" : "password"}
          name="password"
          value={data.password}
          className="text-input"
          autoComplete="current-password"
          onChange={(e) => setData("password", e.target.value)}
          placeholder="Password"
        />
        <InputError message={errors.password} className="mt-2" />
        <div className="flex justify-between mt-6">
          <label
            htmlFor="show_password"
            className="flex items-center cursor-pointer"
          >
            <Checkbox
              name="show_password"
              id="show_password"
              checked={data.remember}
              onChange={togglePasswordVisiblity}
            />
            <span className="ms-2">Show password</span>
          </label>

          {canResetPassword && (
            <Link
              href={route("password.request")}
              className="underline text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
            >
              Forgot your password?
            </Link>
          )}
        </div>
        <button class="w-full mt-6 h-12 text-white text-center text-base font-semibold leading-6 rounded-full hover:bg-indigo-800 transition-all duration-700 bg-indigo-600 shadow-sm mb-11">
          Login
        </button>
        <Link
          href={route("register")}
          className="flex justify-center text-base font-medium leading-6"
        >
          Don’t have an account?
          <span class="text-indigo-500 font-semibold pl-3"> Sign Up</span>
        </Link>
      </form>
    </GuestLayout>
  );
}
