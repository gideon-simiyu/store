import { Fragment, useState } from "react";
import ApplicationLogo from "@/Components/ApplicationLogo";
import Dropdown from "@/Components/Dropdown";
import NavLink from "@/Components/NavLink";
import ResponsiveNavLink from "@/Components/ResponsiveNavLink";
import { Link } from "@inertiajs/react";
import Footer from "@/Components/Footer";
import {
  BuildingStorefrontIcon,
  HomeIcon,
  ListBulletIcon,
  LockClosedIcon,
  LockOpenIcon,
  ShoppingCartIcon,
  UserCircleIcon,
} from "@heroicons/react/20/solid";
import ThemeSwitcher from "@/Components/ThemeSwitcher";
import Harmbuger from "@/Components/Harmbuger";

export default function Authenticated({ user, header, children }) {
  const [showingNavigationDropdown, setShowingNavigationDropdown] =
    useState(false);

  return (
    <div class="relative flex flex-col min-h-screen">
      <nav class="bg-white shadow-lg dark:bg-gray-950 py-3.5 px-6  w-full lg:shadow-none fixed z-50">
        <div class="flex items-center justify-between gap-1 sm:gap-6 lg:flex-row flex-col">
          <div class="flex justify-between items-center lg:w-auto w-full">
            <ThemeSwitcher className="lg:hidden" />
            <a href="#" class="block">
              <ApplicationLogo />
            </a>
            <button
              id="navbar-toggle"
              type="button"
              class="inline-flex items-center p-2 ml-3 text-sm  rounded-lg lg:hidden focus:outline-none "
              aria-controls="navbar-default"
              aria-expanded="false"
              onClick={() =>
                setShowingNavigationDropdown(!showingNavigationDropdown)
              }
            >
              <span class="sr-only">Open main menu</span>
              <Harmbuger checked={showingNavigationDropdown} />
            </button>
          </div>
          <div
            id="mobile-navbar"
            class={`${!showingNavigationDropdown && "hidden"} lg:flex flex-row w-full flex-1`}
          >
            <ul class="text-center flex lg:flex-row flex-col lg:gap-2 xl:gap-4 gap-2 items-start lg:ml-auto">
              <NavLink route={route("home")} active={route().current("home")}>
                <span className="ms-2">Home</span>
              </NavLink>
              <NavLink route={route("shop")} active={route().current("shop")}>
                <span className="ms-2">Shop</span>
              </NavLink>
              <NavLink route={route("cart")} active={route().current("cart")}>
                <span className="ms-2">Cart</span>
              </NavLink>
              <NavLink route={route("home")} active={route().current("orders")}>
                <span className="ms-2">Orders</span>
              </NavLink>
              <NavLink
                route={route("profile.edit")}
                active={route().current("profile.edit")}
              >
                <span className="ms-2">Profile</span>
              </NavLink>
              <NavLink
                route={route("logout")}
                active={route().current("logout")}
                method="post"
                as="button"
              >
                <span className="ms-2">Logout</span>
              </NavLink>
            </ul>
            <div class="text-center lg:flex  items-center gap-1  sm:gap-4 lg:ml-auto">
              <div class=" flex items-center lg:justify-start justify-center gap-1 sm:gap-2">
                <ThemeSwitcher className="hidden lg:inline-flex" />
              </div>
            </div>
          </div>
        </div>
      </nav>
      <div class="pt-[68px] flex-grow flex flex-col">
        <div class="py-3.5 lg:px-8 px-3 bg-gray-300 dark:bg-gray-800">
          <div class="block max-lg:pl-6">
            <h6 class="text-sm sm:text-lg font-semibold text-gray-900 dark:text-white whitespace-nowrap mb-1.5">
              Welcome back ,
              <span class="text-indigo-600 text-base sm:text-lg font-semibold px-2">
                {user.name}
              </span>
            </h6>
            <p class="text-lg font-medium text-gray-900 dark:text-white">
              Home
            </p>
          </div>
        </div>
        <div class="w-full flex-grow p-8 bg-gray-200 text-gray-900 dark:text-gray-100 dark:bg-gray-900">
          {children}
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-screen bg-gray-100 dark:bg-gray-900 flex flex-col">
      <nav className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="shrink-0 flex items-center">
                <Link href="/">
                  <ApplicationLogo className="block h-9 w-auto fill-current text-gray-800 dark:text-gray-200" />
                </Link>
              </div>

              <div className="hidden space-x-8 sm:-my-px sm:ms-10 sm:flex">
                {user.is_staff ? (
                  <Fragment>
                    <NavLink
                      href={route("home")}
                      active={route().current("home")}
                    >
                      Dashboard
                    </NavLink>
                    <NavLink
                      href={route("categories")}
                      active={route().current("categories")}
                    >
                      Categories
                    </NavLink>
                    <NavLink
                      href={route("product_types")}
                      active={route().current("product_types")}
                    >
                      Product Types
                    </NavLink>
                    <NavLink
                      href={route("products")}
                      active={route().current("products")}
                    >
                      Products
                    </NavLink>
                    <NavLink
                      href={route("dashboard")}
                      active={route().current("dashboard")}
                    >
                      Customers
                    </NavLink>
                    <NavLink
                      href={route("dashboard")}
                      active={route().current("dashboard")}
                    >
                      Orders
                    </NavLink>
                  </Fragment>
                ) : (
                  <Fragment>
                    <NavLink
                      href={route("home")}
                      active={route().current("home")}
                    >
                      Home
                    </NavLink>
                    <NavLink
                      href={route("shop")}
                      active={route().current("shop")}
                    >
                      Shop
                    </NavLink>
                    <NavLink
                      href={route("cart")}
                      active={route().current("cart")}
                    >
                      Cart
                    </NavLink>
                    <NavLink
                      href={route("dashboard")}
                      active={route().current("dashboard")}
                    >
                      Orders
                    </NavLink>
                  </Fragment>
                )}
              </div>
            </div>

            <div className="hidden sm:flex sm:items-center sm:ms-6">
              <div className="ms-3 relative">
                <Dropdown>
                  <Dropdown.Trigger>
                    <span className="inline-flex rounded-md">
                      <button
                        type="button"
                        className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none transition ease-in-out duration-150"
                      >
                        {user.name}

                        <svg
                          className="ms-2 -me-0.5 h-4 w-4"
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 20 20"
                          fill="currentColor"
                        >
                          <path
                            fillRule="evenodd"
                            d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                            clipRule="evenodd"
                          />
                        </svg>
                      </button>
                    </span>
                  </Dropdown.Trigger>

                  <Dropdown.Content>
                    <Dropdown.Link href={route("profile.edit")}>
                      Profile
                    </Dropdown.Link>
                    <Dropdown.Link
                      href={route("logout")}
                      method="post"
                      as="button"
                    >
                      Log Out
                    </Dropdown.Link>
                  </Dropdown.Content>
                </Dropdown>
              </div>
            </div>

            <div className="-me-2 flex items-center sm:hidden">
              <button
                onClick={() =>
                  setShowingNavigationDropdown(
                    (previousState) => !previousState,
                  )
                }
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 dark:text-gray-500 hover:text-gray-500 dark:hover:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none focus:bg-gray-100 dark:focus:bg-gray-900 focus:text-gray-500 dark:focus:text-gray-400 transition duration-150 ease-in-out"
              >
                <svg
                  className="h-6 w-6"
                  stroke="currentColor"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <path
                    className={
                      !showingNavigationDropdown ? "inline-flex" : "hidden"
                    }
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                  <path
                    className={
                      showingNavigationDropdown ? "inline-flex" : "hidden"
                    }
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>

        <div
          className={
            (showingNavigationDropdown ? "block" : "hidden") + " sm:hidden"
          }
        >
          <div className="pt-2 pb-3 space-y-1">
            {user.is_staff ? (
              <Fragment>
                <ResponsiveNavLink
                  href={route("home")}
                  active={route().current("home")}
                >
                  Dashboard
                </ResponsiveNavLink>
                <ResponsiveNavLink
                  href={route("categories")}
                  active={route().current("categories")}
                >
                  Categories
                </ResponsiveNavLink>
                <ResponsiveNavLink
                  href={route("product_types")}
                  active={route().current("product_types")}
                >
                  Product Types
                </ResponsiveNavLink>
                <ResponsiveNavLink
                  href={route("products")}
                  active={route().current("products")}
                >
                  Products
                </ResponsiveNavLink>
                <ResponsiveNavLink
                  href={route("dashboard")}
                  active={route().current("dashboard")}
                >
                  Customers
                </ResponsiveNavLink>
                <ResponsiveNavLink
                  href={route("dashboard")}
                  active={route().current("dashboard")}
                >
                  Orders
                </ResponsiveNavLink>
              </Fragment>
            ) : (
              <Fragment>
                <ResponsiveNavLink
                  href={route("home")}
                  active={route().current("home")}
                >
                  Home
                </ResponsiveNavLink>
                <ResponsiveNavLink
                  href={route("shop")}
                  active={route().current("shop")}
                >
                  Shop
                </ResponsiveNavLink>
                <ResponsiveNavLink
                  href={route("cart")}
                  active={route().current("cart")}
                >
                  Cart
                </ResponsiveNavLink>
                <ResponsiveNavLink
                  href={route("dashboard")}
                  active={route().current("dashboard")}
                >
                  Orders
                </ResponsiveNavLink>
              </Fragment>
            )}
          </div>

          <div className="pt-4 pb-1 border-t border-gray-200 dark:border-gray-600">
            <div className="px-4">
              <div className="font-medium text-base text-gray-800 dark:text-gray-200">
                {user.name}
              </div>
              <div className="font-medium text-sm text-gray-500">
                {user.email}
              </div>
            </div>

            <div className="mt-3 space-y-1">
              <ResponsiveNavLink href={route("profile.edit")}>
                Profile
              </ResponsiveNavLink>
              <ResponsiveNavLink
                method="post"
                href={route("logout")}
                as="button"
              >
                Log Out
              </ResponsiveNavLink>
            </div>
          </div>
        </div>
      </nav>

      {header && (
        <header className="bg-white dark:bg-gray-800 shadow">
          <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            {header}
          </div>
        </header>
      )}

      <main className="flex-grow h-full overflow-auto">
        <div className="py-12">
          <div className=" mx-auto sm:px-6 lg:px-8">
            <div className="overflow-hidden shadow-sm sm:rounded-lg">
              <div className="text-gray-900 dark:text-gray-100">{children}</div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
