import { Fragment, useState } from "react";
import ApplicationLogo from "@/Components/ApplicationLogo";
import Dropdown from "@/Components/Dropdown";
import NavLink from "@/Components/NavLink";
import ResponsiveNavLink from "@/Components/ResponsiveNavLink";
import { Link } from "@inertiajs/react";
import Footer from "@/Components/Footer";
import {
  BuildingStorefrontIcon,
  HomeIcon,
  LockOpenIcon,
  UserPlusIcon,
} from "@heroicons/react/20/solid";
import ThemeSwitcher from "@/Components/ThemeSwitcher";
import Harmbuger from "@/Components/Harmbuger";

export default function Guest({ children, auth = true, header }) {
  const [showingNavigationDropdown, setShowingNavigationDropdown] =
    useState(false);

  return (
    <div
      class={`relative min-h-screen ${auth && "flex flex-col justify-between pt-6 sm:pt-0"}`}
    >
      <nav class="bg-white shadow-lg dark:bg-gray-950 py-3.5 px-6  w-full lg:shadow-none fixed z-50">
        <div class="flex items-center justify-between gap-1 sm:gap-6 lg:flex-row flex-col">
          <div class="flex justify-between items-center lg:w-auto w-full">
            <ThemeSwitcher className="lg:hidden" />
            <a href="#" class="block">
              <ApplicationLogo />
            </a>
            <button
              id="navbar-toggle"
              type="button"
              class="inline-flex items-center mr-3 text-sm rounded-lg lg:hidden focus:outline-none "
              aria-controls="navbar-default"
              aria-expanded="false"
              onClick={() =>
                setShowingNavigationDropdown(!showingNavigationDropdown)
              }
            >
              <span class="sr-only">Open main menu</span>

              <Harmbuger checked={showingNavigationDropdown} />
            </button>
          </div>
          <div
            id="mobile-navbar"
            class={`${!showingNavigationDropdown && "hidden"} lg:flex flex-row w-full flex-1`}
          >
            <ul class="text-center flex lg:flex-row flex-col lg:gap-2 xl:gap-4 gap-2 items-start lg:ml-auto">
              <NavLink route={route("home")} active={route().current("home")}>
                <span className="ms-2">Home</span>
              </NavLink>
              <NavLink route={route("shop")} active={route().current("shop")}>
                <span className="ms-2">Shop</span>
              </NavLink>
              <NavLink route={route("login")} active={route().current("login")}>
                <span className="ms-2">Login</span>
              </NavLink>
              <NavLink
                route={route("register")}
                active={route().current("register")}
              >
                <span className="ms-2">Register</span>
              </NavLink>
            </ul>
            <div class="text-center lg:flex  items-center gap-1  sm:gap-4 lg:ml-auto">
              <div class=" flex items-center lg:justify-start justify-center gap-1 sm:gap-2">
                <ThemeSwitcher className="hidden lg:inline-flex" />
              </div>
            </div>
          </div>
        </div>
      </nav>
      <div class="pt-[68px] bg-gray-200 text-gray-900 dark:text-gray-100 dark:bg-gray-900 flex-grow flex flex-col">
        <div class="py-3.5 lg:px-8 px-3 bg-gray-300 dark:bg-gray-800">
          <div class="block max-lg:pl-6">
            <p class="text-lg font-medium text-gray-900 dark:text-white">
              Home
            </p>
          </div>
        </div>
        <div
          class={`w-full p-8 flex-grow ${auth && "flex flex-col justify-center items-center"}`}
        >
          {auth ? (
            <div className="mx-auto max-w-2xl px-6 lg:px-8 rounded-2xl bg-primary shadow-xl">
              {children}
            </div>
          ) : (
            <Fragment>{children} </Fragment>
          )}
        </div>
      </div>
    </div>
  );
  return (
    <div
      className={`min-h-screen ${auth && "flex flex-col justify-between pt-6 sm:pt-0"} bg-gray-100 dark:bg-gray-900`}
    >
      <nav className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="shrink-0 flex items-center">
                <Link href="/">
                  <ApplicationLogo className="block h-9 w-auto fill-current text-gray-800 dark:text-gray-200" />
                </Link>
              </div>

              <div className="hidden space-x-8 sm:-my-px sm:ms-10 sm:flex">
                <NavLink href={route("home")} active={route().current("home")}>
                  Home
                </NavLink>
                <NavLink href={route("shop")} active={route().current("shop")}>
                  Shop
                </NavLink>
              </div>
            </div>

            <div className="hidden sm:flex sm:items-center sm:ms-6">
              <div className="ms-3 relative flex space-x-6">
                <NavLink
                  href={route("login")}
                  active={route().current("login")}
                >
                  Login
                </NavLink>
                <NavLink
                  href={route("register")}
                  active={route().current("register")}
                >
                  Register
                </NavLink>
              </div>
            </div>

            <div className="-me-2 flex items-center sm:hidden">
              <button
                onClick={() =>
                  setShowingNavigationDropdown(
                    (previousState) => !previousState,
                  )
                }
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 dark:text-gray-500 hover:text-gray-500 dark:hover:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none focus:bg-gray-100 dark:focus:bg-gray-900 focus:text-gray-500 dark:focus:text-gray-400 transition duration-150 ease-in-out"
              >
                <svg
                  className="h-6 w-6"
                  stroke="currentColor"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <path
                    className={
                      !showingNavigationDropdown ? "inline-flex" : "hidden"
                    }
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                  <path
                    className={
                      showingNavigationDropdown ? "inline-flex" : "hidden"
                    }
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>

        <div
          className={
            (showingNavigationDropdown ? "block" : "hidden") + " sm:hidden"
          }
        >
          <div className="pt-2 pb-3 space-y-1">
            <ResponsiveNavLink
              href={route("home")}
              active={route().current("home")}
            >
              Dashboard
            </ResponsiveNavLink>
            <ResponsiveNavLink
              href={route("shop")}
              active={route().current("shop")}
            >
              Shop
            </ResponsiveNavLink>
          </div>

          <div className="pt-4 pb-1 border-t border-gray-200 dark:border-gray-600">
            <div className="mt-3 space-y-1">
              <ResponsiveNavLink href={route("login")}>Login</ResponsiveNavLink>
              <ResponsiveNavLink href={route("register")}>
                Register
              </ResponsiveNavLink>
            </div>
          </div>
        </div>
      </nav>

      {header && (
        <header className="bg-white dark:bg-gray-800 shadow">
          <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            {header}
          </div>
        </header>
      )}

      {auth ? (
        <div className="flex flex-col sm:justify-center items-center flex-grow px-6">
          <div className="w-full sm:max-w-md mt-6 px-6 py-4 bg-primary shadow-md overflow-hidden rounded-lg">
            {children}
          </div>
        </div>
      ) : (
        <main>
          <div className="py-12">
            <div className=" mx-auto sm:px-6 lg:px-8">
              <div className="overflow-hidden shadow-sm sm:rounded-lg">
                <div className="text-gray-900 dark:text-gray-100">
                  {children}
                </div>
              </div>
            </div>
          </div>
        </main>
      )}
    </div>
  );
}
