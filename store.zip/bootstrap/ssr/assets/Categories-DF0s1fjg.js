import { jsxs, jsx } from "react/jsx-runtime";
import { I as InputLabel } from "./InputLabel-CaoVq05r.js";
import { M as Modal } from "./Modal-hwUWdjEz.js";
import { T as TextInput } from "./TextInput-7T30eInL.js";
import { A as Authenticated } from "./AuthenticatedLayout-BEcBcb0X.js";
import { useForm, Head } from "@inertiajs/react";
import { useState } from "react";
import { D as DataTable } from "./DataTable-CLuFBKLO.js";
import "@headlessui/react";
import "./Harmbuger-ZdqdIL5A.js";
import "framer-motion";
function Categories({ auth, categories }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);
  const { data, setData, post, processing, errors, reset } = useForm({
    name: "",
    description: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("categories.create"), {
      onFinish: () => {
        reset("name", "description");
        closeModal();
      }
    });
  };
  const headers = ["Name", "Description", "Created On"];
  const columns = ["name", "description", "created_at"];
  const datax100 = Array.from({ length: 100 }, (_, i) => ({
    id: i + 1,
    name: `Category ${i + 1}`,
    description: `Category ${i + 1} description`,
    created_at: (/* @__PURE__ */ new Date()).toLocaleDateString()
  }));
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight", children: "Categories" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Category" }),
        /* @__PURE__ */ jsxs("div", { className: "bg-primary shadow-lg p-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-3", children: [
            /* @__PURE__ */ jsx("h1", { className: "text-2xl", children: "Categories" }),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: openModal,
                className: "bg-indigo-500 text-white px-3 py-2",
                children: "Create Category"
              }
            )
          ] }),
          /* @__PURE__ */ jsx("hr", {}),
          /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(DataTable, { data: datax100, columns, headers }) })
        ] }),
        /* @__PURE__ */ jsx(
          Modal,
          {
            closeable: true,
            show: isModalOpen,
            onClose: closeModal,
            title: "Create Product",
            children: /* @__PURE__ */ jsxs("div", { className: "p-6", children: [
              /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsx("h2", { className: "text-2xl py-3 font-semibold text-gray-800 dark:text-gray-200 leading-tight", children: "Create Category" }),
                /* @__PURE__ */ jsx("hr", {})
              ] }),
              /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(InputLabel, { htmlFor: "name", value: "Category Name" }),
                  /* @__PURE__ */ jsx(
                    TextInput,
                    {
                      name: "name",
                      id: "name",
                      className: "mt-1 block w-full",
                      isFocused: true,
                      onChange: (e) => setData("name", e.target.value),
                      value: data.name
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(InputLabel, { htmlFor: "description", value: "Category Description" }),
                  /* @__PURE__ */ jsx(
                    TextInput,
                    {
                      name: "description",
                      id: "description",
                      className: "mt-1 block w-full",
                      onChange: (e) => setData("description", e.target.value),
                      value: data.description
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx("div", { className: "mb-4 flex justify-end", children: /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "submit",
                    className: "px-4 py-2 text-white bg-indigo-600 rounded-lg hover:bg-indigo-500",
                    children: "Save"
                  }
                ) })
              ] })
            ] })
          }
        )
      ]
    }
  );
}
export {
  Categories as default
};
