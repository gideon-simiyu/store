import { jsx, jsxs } from "react/jsx-runtime";
import { B as BreadCrumbIcon, S as StarRatingIcon, C as CartIcon } from "./Icons-XXBKsMCK.js";
import { A as Authenticated } from "./AuthenticatedLayout-BEcBcb0X.js";
import { useForm, Link } from "@inertiajs/react";
import { Fragment } from "react";
import "framer-motion";
import "./Harmbuger-ZdqdIL5A.js";
function View({ auth, product, sizes = [] }) {
  const rating = parseInt(product.rating.toString());
  const unrated = 5 - rating;
  const { data, setData, post, processing, errors, reset } = useForm({
    product_id: product.id,
    size: "",
    quantity: 1
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("cart.add"), {
      onFinish: () => reset("quantity")
    });
  };
  return /* @__PURE__ */ jsx(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsxs("div", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight flex space-x-2", children: [
        /* @__PURE__ */ jsx(Link, { className: "breadcrumb-link", href: route("home"), children: "Home" }),
        /* @__PURE__ */ jsx(BreadCrumbIcon, {}),
        /* @__PURE__ */ jsx(Link, { className: "breadcrumb-link", href: route("products"), children: "Products" }),
        " ",
        /* @__PURE__ */ jsx(BreadCrumbIcon, {}),
        /* @__PURE__ */ jsx("span", { children: product.name })
      ] }),
      children: /* @__PURE__ */ jsx("div", { className: "container flex justify-center mx-auto", children: /* @__PURE__ */ jsx("section", { class: "relative max-w-fit", children: /* @__PURE__ */ jsx("div", { class: "w-full mx-auto px-4 sm:px-6 lg:px-0", children: /* @__PURE__ */ jsxs("div", { class: "grid grid-cols-1 lg:grid-cols-2 gap-16 mx-auto max-md:px-2 ", children: [
        /* @__PURE__ */ jsx("div", { class: "img", children: /* @__PURE__ */ jsx("div", { class: "h-full max-lg:mx-auto rounded-xl bg-gray-300 dark:bg-gray-800 p-2", children: /* @__PURE__ */ jsx(
          "img",
          {
            src: `/storage/${product.image}`,
            alt: product.name,
            class: "max-lg:mx-auto lg:ml-auto h-full rounded-lg"
          }
        ) }) }),
        /* @__PURE__ */ jsx("div", { class: "data w-full lg:pr-8 pr-0 xl:justify-start justify-center flex items-start max-lg:pb-10 xl:my-2 lg:my-5 my-0", children: /* @__PURE__ */ jsxs("div", { class: "data w-full max-w-xl", children: [
          /* @__PURE__ */ jsxs("p", { class: "text-lg font-medium leading-8 text-indigo-600 mb-4", children: [
            /* @__PURE__ */ jsx("span", { className: "capitalize", children: product.category.name }),
            "  / ",
            " ",
            /* @__PURE__ */ jsx("span", { className: "capitalize", children: product.product_type.name })
          ] }),
          /* @__PURE__ */ jsx("h2", { class: "font-manrope font-bold text-3xl leading-10 mb-2 capitalize", children: product.name }),
          /* @__PURE__ */ jsxs("div", { class: "flex flex-col sm:flex-row sm:items-center mb-6", children: [
            /* @__PURE__ */ jsx("h6", { class: "font-manrope font-semibold text-2xl leading-9 pr-5 sm:border-r border-gray-200 mr-5", children: "$220" }),
            /* @__PURE__ */ jsxs("div", { class: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxs("div", { class: "flex items-center gap-1", children: [
                [...Array(rating)].map((_, index) => /* @__PURE__ */ jsx(StarRatingIcon, { index }, index)),
                [...Array(unrated)].map((_, index) => /* @__PURE__ */ jsx(
                  StarRatingIcon,
                  {
                    index,
                    className: "h-6 w-6 text-gray-300"
                  },
                  index
                ))
              ] }),
              /* @__PURE__ */ jsx("span", { class: "pl-2 font-normal leading-7 text-sm ", children: "1624 review" })
            ] })
          ] }),
          /* @__PURE__ */ jsx("p", { class: "text-base font-normal mb-5", children: "Introducing our vibrant Basic Yellow Tropical Printed Shirt - a celebration of style and sunshine! Embrace the essence of summer wherever you go with this eye-catching piece that effortlessly blends comfort and tropical flair." }),
          sizes.length > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx("p", { class: " text-lg leading-8 font-medium mb-4", children: "Size" }),
            /* @__PURE__ */ jsx("div", { class: "w-full pb-8 border-b border-gray-100 flex-wrap", children: /* @__PURE__ */ jsx("div", { class: "grid grid-cols-3 min-[400px]:grid-cols-5 gap-3 max-w-md", children: sizes.map((size) => /* @__PURE__ */ jsx("button", { class: "text-center py-1.5 px-6 w-full font-semibold text-lg leading-8 border border-indigo-600 flex items-center rounded-full justify-center transition-all duration-300 hover:bg-indigo-600 hover:text-white", children: "S" })) }) })
          ] }),
          /* @__PURE__ */ jsxs("div", { class: "grid grid-cols-1 sm:grid-cols-2 gap-3 py-8", children: [
            /* @__PURE__ */ jsxs("div", { class: "flex sm:items-center sm:justify-center w-full", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  onClick: () => {
                    if (data.quantity > 1) {
                      setData("quantity", data.quantity - 1);
                    }
                  },
                  class: "group py-4 px-6 border border-indigo-600 rounded-l-full bg-transparent transition-all duration-300 hover:bg-indigo-600 hover:text-white",
                  children: "-"
                }
              ),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  class: "font-semibold cursor-pointer text-lg py-[13px] px-6 w-full sm:max-w-[118px] outline-0 border-y border-indigo-600 bg-transparent placeholder: text-center hover:bg-indigo-600 hover:text-white transition-all duration-300",
                  value: data.quantity,
                  readOnly: true
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  onClick: () => setData("quantity", data.quantity + 1),
                  class: "group py-4 px-6 border border-indigo-600 rounded-r-full transition-all duration-300 hover:bg-indigo-600 hover:text-white",
                  children: "+"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: submit,
                class: "group py-4 px-5 rounded-full text-white bg-indigo-950 font-semibold text-lg w-full flex items-center justify-center gap-2 transition-all duration-500 hover:bg-indigo-600 hover:text-white",
                children: [
                  /* @__PURE__ */ jsx(CartIcon, {}),
                  "Add to cart"
                ]
              }
            )
          ] })
        ] }) })
      ] }) }) }) })
    }
  );
}
export {
  View as default
};
