import { jsxs, jsx } from "react/jsx-runtime";
import { A as Authenticated } from "./AuthenticatedLayout-BEcBcb0X.js";
import { Link, Head, useForm } from "@inertiajs/react";
import { B as BreadCrumbIcon } from "./Icons-XXBKsMCK.js";
import { G as Guest } from "./GuestLayout-CKc0me1J.js";
import { C as ClothingShopLogo } from "./Harmbuger-ZdqdIL5A.js";
import { P as ProductDisplay } from "./ProductDisplay-BxTQFFi7.js";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import "@heroicons/react/20/solid";
function Shop({
  auth,
  products,
  categories,
  product_types
}) {
  if (auth.user) {
    return /* @__PURE__ */ jsxs(
      Authenticated,
      {
        user: auth.user,
        header: /* @__PURE__ */ jsxs("div", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight flex space-x-2", children: [
          /* @__PURE__ */ jsx(Link, { className: "breadcrumb-link", href: route("home"), children: "Home" }),
          /* @__PURE__ */ jsx(BreadCrumbIcon, {}),
          /* @__PURE__ */ jsx("span", { children: "Shop" }),
          /* @__PURE__ */ jsx(BreadCrumbIcon, {}),
          /* @__PURE__ */ jsx("span", { children: "All Products" })
        ] }),
        children: [
          /* @__PURE__ */ jsx(Head, { title: "Shop" }),
          /* @__PURE__ */ jsx(
            ShopComponent,
            {
              ...{ auth, products, categories, product_types }
            }
          )
        ]
      }
    );
  }
  return /* @__PURE__ */ jsxs(
    Guest,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsxs("div", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight flex space-x-2", children: [
        /* @__PURE__ */ jsx(Link, { className: "breadcrumb-link", href: route("home"), children: "Home" }),
        /* @__PURE__ */ jsx(BreadCrumbIcon, {}),
        /* @__PURE__ */ jsx("span", { children: "Shop" }),
        /* @__PURE__ */ jsx(BreadCrumbIcon, {}),
        /* @__PURE__ */ jsx("span", { children: "All Products" })
      ] }),
      auth: false,
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Shop" }),
        /* @__PURE__ */ jsx(
          ShopComponent,
          {
            ...{ auth, products, categories, product_types }
          }
        )
      ]
    }
  );
}
const ShopComponent = ({ auth, products, categories, product_types }) => {
  console.log(products);
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };
  const [displayProducts, setDisplayProducts] = useState([]);
  const { data, setData, post, processing, errors, reset } = useForm({
    category: [],
    product_type: []
  });
  const handleCategory = (e) => {
    let category = data.category;
    if (e.target.checked) {
      category.push(e.target.value);
    } else {
      category = category.filter((item) => item !== e.target.value);
    }
    setData("category", category);
  };
  const handleProductType = (e) => {
    let product_type = data.product_type;
    if (e.target.checked) {
      product_type.push(e.target.value);
    } else {
      product_type = product_type.filter((item) => item !== e.target.value);
    }
    setData("product_type", product_type);
  };
  const filter = (e) => {
    e.preventDefault();
    post(route("products.filter"), {
      onFinish: (data2) => {
        console.log(data2);
      },
      data,
      preserveState: true
    });
  };
  const sort = (e) => {
    e.preventDefault();
    const sortOrder = e.target.value;
    const sortedProducts = [...products];
    if (sortOrder === "high") {
      sortedProducts.sort((a, b) => b.price - a.price);
      setDisplayProducts(sortedProducts);
    } else if (sortOrder === "low") {
      sortedProducts.sort((a, b) => a.price - b.price);
      setDisplayProducts(sortedProducts);
    } else {
      setDisplayProducts(products);
    }
  };
  useEffect(() => {
    setDisplayProducts(products);
  }, [products]);
  return /* @__PURE__ */ jsx("section", { class: "relative", children: /* @__PURE__ */ jsxs("div", { class: "w-full mx-auto px-4 md:px-8", children: [
    /* @__PURE__ */ jsxs("div", { class: "flex flex-col lg:flex-row lg:items-center max-lg:gap-4 justify-between w-full", children: [
      /* @__PURE__ */ jsx("p", { class: "text-lg hidden md:block font-medium leading-8 text-indigo-600 mb-4", children: /* @__PURE__ */ jsx(ClothingShopLogo, { className: "h-6 w-6 inline-block" }) }),
      /* @__PURE__ */ jsxs("div", { class: "relative w-full max-w-sm", children: [
        /* @__PURE__ */ jsx(
          "svg",
          {
            class: "absolute top-1/2 -translate-y-1/2 left-4 z-50 text-gray-900 dark:text-gray-200",
            width: "20",
            height: "20",
            viewBox: "0 0 20 20",
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg",
            children: /* @__PURE__ */ jsx(
              "path",
              {
                d: "M16.5555 3.33203H3.44463C2.46273 3.33203 1.66675 4.12802 1.66675 5.10991C1.66675 5.56785 1.84345 6.00813 2.16004 6.33901L6.83697 11.2271C6.97021 11.3664 7.03684 11.436 7.0974 11.5068C7.57207 12.062 7.85127 12.7576 7.89207 13.4869C7.89728 13.5799 7.89728 13.6763 7.89728 13.869V16.251C7.89728 17.6854 9.30176 18.6988 10.663 18.2466C11.5227 17.961 12.1029 17.157 12.1029 16.251V14.2772C12.1029 13.6825 12.1029 13.3852 12.1523 13.1015C12.2323 12.6415 12.4081 12.2035 12.6683 11.8158C12.8287 11.5767 13.0342 11.3619 13.4454 10.9322L17.8401 6.33901C18.1567 6.00813 18.3334 5.56785 18.3334 5.10991C18.3334 4.12802 17.5374 3.33203 16.5555 3.33203Z",
                stroke: "currentColor",
                "stroke-width": "1.6",
                "stroke-linecap": "round"
              }
            )
          }
        ),
        /* @__PURE__ */ jsxs(
          "select",
          {
            id: "Offer",
            onChange: sort,
            class: "h-12 border border-indigo-700 text-gray-900 dark:text-gray-200 pl-11 text-base font-normal leading-7 rounded-full block w-full py-2.5 px-4 appearance-none relative focus:outline-none bg-transparent transition-all duration-500 hover:border-gray-400",
            children: [
              /* @__PURE__ */ jsx("option", { value: "relevance", className: "bg-primary", selected: true, children: "Sort by relevance" }),
              /* @__PURE__ */ jsx("option", { value: "high", className: "bg-primary", children: "Sort by price(high to low)" }),
              /* @__PURE__ */ jsx("option", { value: "low", className: "bg-primary", children: "Sort by price(low to high)" })
            ]
          }
        ),
        /* @__PURE__ */ jsx(
          "svg",
          {
            class: "absolute top-1/2 -translate-y-1/2 right-4 z-50",
            width: "16",
            height: "16",
            viewBox: "0 0 16 16",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /* @__PURE__ */ jsx(
              "path",
              {
                d: "M12.0002 5.99845L8.00008 9.99862L3.99756 5.99609",
                stroke: "#111827",
                "stroke-width": "1.6",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }
            )
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx("hr", { className: "my-6" }),
    /* @__PURE__ */ jsxs("div", { class: "grid grid-cols-12", children: [
      /* @__PURE__ */ jsx("div", { class: "col-span-12 md:col-span-3 w-full max-md:max-w-md max-md:mx-auto md:max-w-sm", children: /* @__PURE__ */ jsxs("div", { className: "box bg-primary p-6 rounded-lg", children: [
        /* @__PURE__ */ jsxs("div", { class: "mb-7", children: [
          /* @__PURE__ */ jsx("p", { class: "font-medium text-sm leading-6 mb-3", children: "Category" }),
          /* @__PURE__ */ jsx("div", { class: "box flex gap-4 flex-wrap", children: categories.map((category) => /* @__PURE__ */ jsxs("div", { class: "flex items-center mb-1", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                id: `category-${category.id}`,
                type: "checkbox",
                name: "category",
                value: category.id,
                onClick: handleCategory,
                class: "w-5 h-5 appearance-none border border-gray-300  rounded-md mr-2 hover:border-indigo-500 hover:bg-indigo-100 checked:bg-no-repeat checked:bg-center checked:border-indigo-500 checked:bg-indigo-100 checked:bg-[url('https://pagedone.io/asset/uploads/1689406942.svg')]"
              }
            ),
            /* @__PURE__ */ jsx(
              "label",
              {
                for: `category-${category.id}`,
                class: "text-sm capitalize font-normal leading-4 cursor-pointer hover:text-indigo-600 dark:hover:text-indigo-200 transition-all duration-500",
                children: category.name
              }
            )
          ] })) })
        ] }),
        /* @__PURE__ */ jsxs("div", { class: "mb-7", children: [
          /* @__PURE__ */ jsx("p", { class: "font-medium text-sm leading-6 mb-3", children: "Category" }),
          /* @__PURE__ */ jsx("div", { class: "box flex flex-wrap gap-4", children: product_types.map((product_type) => /* @__PURE__ */ jsxs("div", { class: "flex items-center mb-1", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                id: `product_type-${product_type.id}`,
                type: "checkbox",
                name: "category",
                value: product_type.id,
                onClick: handleProductType,
                class: "w-5 h-5 appearance-none border border-gray-300  rounded-md mr-2 hover:border-indigo-500 hover:bg-indigo-100 checked:bg-no-repeat checked:bg-center checked:border-indigo-500 checked:bg-indigo-100 checked:bg-[url('https://pagedone.io/asset/uploads/1689406942.svg')]"
              }
            ),
            /* @__PURE__ */ jsx(
              "label",
              {
                for: `product_type-${product_type.id}`,
                class: "text-sm capitalize font-normal leading-4 cursor-pointer hover:text-indigo-600 dark:hover:text-indigo-200 transition-all duration-500",
                children: product_type.name
              }
            )
          ] })) })
        ] }),
        /* @__PURE__ */ jsx("button", { onClick: filter, class: "w-full bg-indigo-600 text-white py-3 rounded-md font-medium text-sm leading-6 hover:bg-indigo-700 transition-all duration-500", children: "Apply Filters" })
      ] }) }),
      /* @__PURE__ */ jsx(
        motion.div,
        {
          variants: containerVariants,
          initial: "hidden",
          animate: "visible",
          className: "flex flex-wrap justify-center col-span-12 md:col-span-9",
          children: displayProducts.map((product, index) => /* @__PURE__ */ jsx(
            motion.div,
            {
              variants: itemVariants,
              className: "lg:basis-1/4 md:basis-1/2 basis-full px-10 md:p-6 lg:p-4 py-5",
              children: /* @__PURE__ */ jsx(ProductDisplay, { product })
            },
            product.id
          ))
        }
      )
    ] })
  ] }) });
};
export {
  Shop as default
};
