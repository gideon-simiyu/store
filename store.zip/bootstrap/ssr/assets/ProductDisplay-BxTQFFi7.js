import { jsxs, jsx } from "react/jsx-runtime";
import { motion } from "framer-motion";
import { S as StarRatingIcon } from "./Icons-XXBKsMCK.js";
import { Link } from "@inertiajs/react";
import { EyeIcon } from "@heroicons/react/20/solid";
import "react";
function ProductDisplay({ auth, product }) {
  const rating = parseInt(product.rating.toString());
  const unrated = 5 - rating;
  const discountedPrice = product.discount > 0 ? product.price - product.discount * product.price / 100 : product.price;
  return /* @__PURE__ */ jsxs(
    motion.div,
    {
      className: "relative min-w-full flex w-full max-w-xs flex-col overflow-hidden rounded-lg text-slate-900 dark:text-white bg-white dark:bg-gray-800 shadow-md",
      whileHover: {
        y: -20,
        boxShadow: "0px 10px 20px rgba(0, 0, 0, 0.3)"
      },
      transition: { duration: 0.5, ease: "easeInOut" },
      whileTap: { scale: 0.95 },
      initial: { opacity: 0, y: 30 },
      whileInView: { opacity: 1, y: 0 },
      viewport: { once: false, amount: 0.1 },
      children: [
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: `/product/${product.id}/view`,
            className: "relative mx-3 mt-3 flex h-96 md:h-60 overflow-hidden rounded-xl bg-gray-300",
            children: [
              /* @__PURE__ */ jsx(
                motion.img,
                {
                  className: "object-cover w-full",
                  src: `/storage/${product.image}`,
                  alt: "product image",
                  initial: { opacity: 0 },
                  animate: { opacity: 1 },
                  transition: { duration: 2 }
                }
              ),
              product.discount > 0 && /* @__PURE__ */ jsxs(
                motion.span,
                {
                  className: "absolute top-0 left-0 m-2 rounded-full bg-indigo-600 px-2 py-1 text-center text-sm font-medium text-white",
                  animate: { scale: [1, 1.2, 1] },
                  transition: {
                    repeat: Infinity,
                    repeatType: "loop",
                    duration: 1.5
                  },
                  children: [
                    product.discount,
                    "% OFF"
                  ]
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "mt-4 px-5 pb-5 mb-2 flex flex-col items-center justify-between space-y-2", children: [
          /* @__PURE__ */ jsx("a", { href: "#", children: /* @__PURE__ */ jsx("h5", { className: "text-xl tracking-tight", children: product.name }) }),
          /* @__PURE__ */ jsxs("p", { className: "flex justify-center space-x-2 items-baseline", children: [
            /* @__PURE__ */ jsxs("span", { className: "text-3xl font-bold", children: [
              "£ ",
              product.price
            ] }),
            product.discount > 0 && /* @__PURE__ */ jsxs("span", { className: "text-sm line-through", children: [
              "£ ",
              discountedPrice.toFixed(2)
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
            [...Array(rating)].map((_, index) => /* @__PURE__ */ jsx(StarRatingIcon, {}, index)),
            [...Array(unrated)].map((_, index) => /* @__PURE__ */ jsx(StarRatingIcon, { className: "h-6 w-6 text-gray-300" }, index)),
            /* @__PURE__ */ jsx("span", { className: "mr-2 ml-3 rounded bg-indigo-600 text-white px-2.5 py-0.5 text-xs font-semibold", children: "5.0" })
          ] }),
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("products.view", { id: product.id }),
              className: "w-full",
              children: /* @__PURE__ */ jsxs(
                motion.button,
                {
                  className: "flex items-center justify-center rounded-md bg-indigo-600 px-5 py-2.5 text-center text-sm font-medium text-white hover:bg-indigo-500 dark:hover:bg-indigo-700 focus:outline-none focus:ring-4 focus:ring-indigo-300 dark:focus:ring-indigo-500 w-full",
                  whileTap: { scale: 0.9 },
                  children: [
                    /* @__PURE__ */ jsx(EyeIcon, { className: "h-6 w-6 me-2" }),
                    "View product"
                  ]
                }
              )
            }
          )
        ] })
      ]
    }
  );
}
export {
  ProductDisplay as P
};
