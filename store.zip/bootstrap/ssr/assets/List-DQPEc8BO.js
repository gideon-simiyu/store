import { jsxs, jsx } from "react/jsx-runtime";
import { I as InputLabel } from "./InputLabel-CaoVq05r.js";
import { M as Modal } from "./Modal-hwUWdjEz.js";
import { T as TextInput } from "./TextInput-7T30eInL.js";
import { A as Authenticated } from "./AuthenticatedLayout-BEcBcb0X.js";
import { useForm, Head } from "@inertiajs/react";
import { useState, useEffect } from "react";
import { D as DataTable } from "./DataTable-CLuFBKLO.js";
import { F as FormSelect } from "./FormSelect-VrKBFzy7.js";
import "@headlessui/react";
import "./Harmbuger-ZdqdIL5A.js";
import "framer-motion";
function List({ auth, products, productTypes, categories }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);
  const { data, setData, post, processing, errors, reset } = useForm({
    category_id: categories[0].id,
    product_type_id: productTypes[0].id,
    name: "",
    description: "",
    price: "",
    image: null
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("products.create"), {
      onFinish: () => {
        reset(
          "category_id",
          "product_type_id",
          "name",
          "description",
          "price",
          "image"
        );
        closeModal();
      },
      onError: () => {
        setShowErrorModal(true);
      }
    });
  };
  useEffect(() => {
    if (productTypes.length > 0) {
      setData("product_type_id", productTypes[0].id);
    }
    if (categories.length > 0) {
      setData("category_id", categories[0].id);
    }
  }, [categories, productTypes]);
  const headers = [
    "name",
    "category",
    "product type",
    "description",
    "price"
  ];
  const columns = [
    "name",
    "category.name",
    "product_type.name",
    "description",
    "price"
  ];
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight", children: "Products" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Products" }),
        /* @__PURE__ */ jsxs("div", { className: "bg-primary shadow-lg p-6 h-full", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-3", children: [
            /* @__PURE__ */ jsx("h1", { className: "text-2xl", children: "Products" }),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: openModal,
                className: "bg-indigo-500 text-white px-3 py-2",
                children: "Create Product"
              }
            )
          ] }),
          /* @__PURE__ */ jsx("hr", {}),
          /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(DataTable, { image: "image", route: "/product", actions: true, view: true, remove: true, headers, columns, data: products }) })
        ] }),
        /* @__PURE__ */ jsx(
          Modal,
          {
            closeable: true,
            show: showErrorModal,
            onClose: () => setShowErrorModal(false),
            title: "Validation Errors",
            children: /* @__PURE__ */ jsxs("div", { className: "p-6", children: [
              /* @__PURE__ */ jsx("h2", { className: "text-2xl py-3 font-semibold text-gray-800 dark:text-gray-200 leading-tight", children: "Validation Errors" }),
              /* @__PURE__ */ jsx("hr", {}),
              /* @__PURE__ */ jsx("ul", { className: "mt-4 list-disc pl-5", children: Object.keys(errors).map((key) => /* @__PURE__ */ jsx("li", { className: "text-red-600", children: errors[key] }, key)) })
            ] })
          }
        ),
        /* @__PURE__ */ jsx(
          Modal,
          {
            closeable: true,
            show: isModalOpen,
            onClose: closeModal,
            title: "Create Product",
            children: /* @__PURE__ */ jsxs("div", { className: "p-6", children: [
              /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsx("h2", { className: "text-2xl py-3 font-semibold text-gray-800 dark:text-gray-200 leading-tight", children: "Create Product" }),
                /* @__PURE__ */ jsx("hr", {})
              ] }),
              /* @__PURE__ */ jsxs("form", { children: [
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(InputLabel, { htmlFor: "category_id", value: "Product Category" }),
                  /* @__PURE__ */ jsx(
                    FormSelect,
                    {
                      name: "category_id",
                      id: "category_id",
                      className: "mt-1",
                      onChange: (e) => setData("category_id", e.target.value),
                      children: categories.map((category) => /* @__PURE__ */ jsx("option", { value: category.id, children: category.name }, category.id))
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(InputLabel, { htmlFor: "product_type_id", value: "Product Type" }),
                  /* @__PURE__ */ jsx(
                    FormSelect,
                    {
                      name: "product_type_id",
                      id: "product_type_id",
                      className: "mt-1",
                      onChange: (e) => setData("product_type_id", e.target.value),
                      children: productTypes.map((productType) => /* @__PURE__ */ jsx("option", { value: productType.id, children: productType.name }, productType.id))
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(InputLabel, { htmlFor: "name", value: "Product Name" }),
                  /* @__PURE__ */ jsx(
                    TextInput,
                    {
                      id: "name",
                      name: "name",
                      className: "mt-1 block w-full",
                      onChange: (e) => setData("name", e.target.value)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(InputLabel, { htmlFor: "description", value: "Product Description" }),
                  /* @__PURE__ */ jsx(
                    TextInput,
                    {
                      id: "description",
                      name: "description",
                      className: "mt-1 block w-full",
                      onChange: (e) => setData("description", e.target.value)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(InputLabel, { htmlFor: "price", value: "Product Price" }),
                  /* @__PURE__ */ jsx(
                    TextInput,
                    {
                      type: "number",
                      id: "price",
                      name: "price",
                      className: "mt-1 block w-full",
                      onChange: (e) => setData("price", e.target.value)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(InputLabel, { htmlFor: "image", value: "Product Image" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "file",
                      id: "image",
                      name: "image",
                      className: "mt-1 block w-full bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm",
                      onChange: (e) => setData("image", e.target.files[0])
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx("div", { className: "mb-4 flex justify-end", children: /* @__PURE__ */ jsx(
                  "button",
                  {
                    onClick: submit,
                    className: "bg-indigo-500 text-white px-3 py-2",
                    disabled: processing,
                    children: processing ? "Creating..." : "Create Product"
                  }
                ) })
              ] })
            ] })
          }
        )
      ]
    }
  );
}
export {
  List as default
};
