import { jsxs, jsx } from "react/jsx-runtime";
import { D as DataTable } from "./DataTable-CLuFBKLO.js";
import { F as FormSelect } from "./FormSelect-VrKBFzy7.js";
import { I as InputLabel } from "./InputLabel-CaoVq05r.js";
import { M as Modal } from "./Modal-hwUWdjEz.js";
import { T as TextInput } from "./TextInput-7T30eInL.js";
import { A as Authenticated } from "./AuthenticatedLayout-BEcBcb0X.js";
import { useForm, Head } from "@inertiajs/react";
import { useState, useEffect } from "react";
import "@headlessui/react";
import "./Harmbuger-ZdqdIL5A.js";
import "framer-motion";
function Types({ auth, productTypes, categories }) {
  console.log(productTypes);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);
  const { data, setData, post, processing, errors, reset } = useForm({
    category_id: "",
    name: "",
    description: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("product_types.create"), {
      onFinish: () => {
        reset("category_id", "name", "description");
        closeModal();
      }
    });
  };
  useEffect(() => {
    setData("category_id", categories[0].id);
  }, [productTypes]);
  const headers = ["category", "name", "description"];
  const columns = ["category.name", "name", "description"];
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight", children: "Product Types" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Product Types" }),
        /* @__PURE__ */ jsxs("div", { className: "bg-primary shadow-lg p-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between py-3", children: [
            /* @__PURE__ */ jsx("h1", { className: "text-2xl", children: "Product Types" }),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: openModal,
                className: "bg-indigo-500 text-white px-3 py-2",
                children: "Create Type"
              }
            )
          ] }),
          /* @__PURE__ */ jsx("hr", {}),
          /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(DataTable, { headers, columns, data: productTypes }) })
        ] }),
        /* @__PURE__ */ jsx(
          Modal,
          {
            closeable: true,
            show: isModalOpen,
            onClose: closeModal,
            title: "Create Product Type",
            children: /* @__PURE__ */ jsxs("div", { className: "p-6", children: [
              /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsx("h2", { className: "text-2xl py-3 font-semibold text-gray-800 dark:text-gray-200 leading-tight", children: "Create Product Type" }),
                /* @__PURE__ */ jsx("hr", {})
              ] }),
              /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(InputLabel, { htmlFor: "category_id", value: "Product Type Category" }),
                  /* @__PURE__ */ jsx(
                    FormSelect,
                    {
                      name: "category_id",
                      id: "category_id",
                      className: "mt-1",
                      onChange: (e) => setData("category_id", e.target.value),
                      children: categories.map((category) => /* @__PURE__ */ jsx("option", { value: category.id, children: category.name }, category.id))
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(InputLabel, { htmlFor: "name", value: "Product Type Name" }),
                  /* @__PURE__ */ jsx(
                    TextInput,
                    {
                      name: "name",
                      id: "name",
                      className: "mt-1 block w-full",
                      onChange: (e) => setData("name", e.target.value),
                      value: data.name
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsx(
                    InputLabel,
                    {
                      htmlFor: "description",
                      value: "Product Type Description"
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    TextInput,
                    {
                      name: "description",
                      id: "description",
                      className: "mt-1 block w-full",
                      onChange: (e) => setData("description", e.target.value),
                      value: data.description
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx("div", { className: "mb-4 flex justify-end", children: /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "submit",
                    className: "px-4 py-2 text-white bg-indigo-600 rounded-lg hover:bg-indigo-500",
                    children: "Save"
                  }
                ) })
              ] })
            ] })
          }
        )
      ]
    }
  );
}
export {
  Types as default
};
