import { jsx, jsxs } from "react/jsx-runtime";
import { G as Guest } from "./GuestLayout-CKc0me1J.js";
import { I as InputError } from "./InputError-PdXTNpsB.js";
import { T as TextInput } from "./TextInput-7T30eInL.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { useState } from "react";
import { C as ClothingShopLogo } from "./Harmbuger-ZdqdIL5A.js";
import "framer-motion";
function Checkbox({ className = "", ...props }) {
  return /* @__PURE__ */ jsx(
    "input",
    {
      ...props,
      type: "checkbox",
      className: "rounded cursor-pointer dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800 " + className
    }
  );
}
function Login({ status, canResetPassword }) {
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: ""
  });
  const [passwordShown, setPasswordShown] = useState(false);
  const togglePasswordVisiblity = () => {
    setPasswordShown(passwordShown ? false : true);
  };
  const submit = (e) => {
    e.preventDefault();
    post(route("login"), {
      onFinish: () => reset("password")
    });
  };
  return /* @__PURE__ */ jsxs(Guest, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Log in" }),
    status && /* @__PURE__ */ jsx("div", { className: "mb-4 font-medium text-green-600", children: status }),
    /* @__PURE__ */ jsxs("form", { class: "lg:p-11 p-7 mx-auto", onSubmit: submit, children: [
      /* @__PURE__ */ jsx("div", { className: "flex justify-center w-full", children: /* @__PURE__ */ jsx(ClothingShopLogo, { className: "mx-auto lg:mb-11 mb-8" }) }),
      /* @__PURE__ */ jsxs("div", { class: "mb-4", children: [
        /* @__PURE__ */ jsx("h1", { class: "text-center font-manrope text-3xl font-bold leading-10 mb-2", children: "Welcome Back" }),
        /* @__PURE__ */ jsx("p", { class: "text-indigo-500 text-center text-base font-medium leading-6", children: "Log in to your account to continue" })
      ] }),
      /* @__PURE__ */ jsx(
        TextInput,
        {
          id: "email",
          type: "email",
          name: "email",
          value: data.email,
          className: "text-input",
          autoComplete: "username",
          isFocused: true,
          placeholder: "Email",
          onChange: (e) => setData("email", e.target.value)
        }
      ),
      /* @__PURE__ */ jsx(InputError, { message: errors.email, className: "mt-2" }),
      /* @__PURE__ */ jsx(
        TextInput,
        {
          id: "password",
          type: passwordShown ? "text" : "password",
          name: "password",
          value: data.password,
          className: "text-input",
          autoComplete: "current-password",
          onChange: (e) => setData("password", e.target.value),
          placeholder: "Password"
        }
      ),
      /* @__PURE__ */ jsx(InputError, { message: errors.password, className: "mt-2" }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-6", children: [
        /* @__PURE__ */ jsxs(
          "label",
          {
            htmlFor: "show_password",
            className: "flex items-center cursor-pointer",
            children: [
              /* @__PURE__ */ jsx(
                Checkbox,
                {
                  name: "show_password",
                  id: "show_password",
                  checked: data.remember,
                  onChange: togglePasswordVisiblity
                }
              ),
              /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Show password" })
            ]
          }
        ),
        canResetPassword && /* @__PURE__ */ jsx(
          Link,
          {
            href: route("password.request"),
            className: "underline text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800",
            children: "Forgot your password?"
          }
        )
      ] }),
      /* @__PURE__ */ jsx("button", { class: "w-full mt-6 h-12 text-white text-center text-base font-semibold leading-6 rounded-full hover:bg-indigo-800 transition-all duration-700 bg-indigo-600 shadow-sm mb-11", children: "Login" }),
      /* @__PURE__ */ jsxs(
        Link,
        {
          href: route("register"),
          className: "flex justify-center text-base font-medium leading-6",
          children: [
            "Don’t have an account?",
            /* @__PURE__ */ jsx("span", { class: "text-indigo-500 font-semibold pl-3", children: " Sign Up" })
          ]
        }
      )
    ] })
  ] });
}
export {
  Login as default
};
