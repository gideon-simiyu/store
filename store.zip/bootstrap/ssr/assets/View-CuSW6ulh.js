import { jsx, jsxs } from "react/jsx-runtime";
function View({ auth, order }) {
  return /* @__PURE__ */ jsx(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsxs("div", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight flex space-x-2", children: [
        /* @__PURE__ */ jsx(Link, { className: "breadcrumb-link", href: route("home"), children: "Home" }),
        /* @__PURE__ */ jsx(BreadCrumbIcon, {}),
        /* @__PURE__ */ jsx(Link, { className: "breadcrumb-link", href: route("orders"), children: "Orders" }),
        " ",
        /* @__PURE__ */ jsx(BreadCrumbIcon, {}),
        /* @__PURE__ */ jsx("span", { children: "Order" })
      ] }),
      children: /* @__PURE__ */ jsx("section", { class: "py-24 relative", children: /* @__PURE__ */ jsxs("div", { class: "w-full max-w-7xl px-4 md:px-5 lg-6 mx-auto", children: [
        /* @__PURE__ */ jsx("h2", { class: "font-manrope font-bold text-4xl leading-10 text-black text-center", children: "Payment Successful" }),
        /* @__PURE__ */ jsx("p", { class: "mt-4 font-normal text-lg leading-8 text-gray-500 mb-11 text-center", children: "Thanks for making a purchase you can check our order summary frm below" }),
        /* @__PURE__ */ jsxs("div", { class: "main-box border border-gray-200 rounded-xl pt-6 max-w-xl max-lg:mx-auto lg:max-w-full", children: [
          /* @__PURE__ */ jsxs(
            "div",
            {
              class: "flex flex-col lg:flex-row lg:items-center justify-between px-6 pb-6 border-b border-gray-200",
              children: [
                /* @__PURE__ */ jsxs("div", { class: "data", children: [
                  /* @__PURE__ */ jsxs("p", { class: "font-semibold text-base leading-7 text-black", children: [
                    "Order Id: ",
                    /* @__PURE__ */ jsx("span", { class: "text-indigo-600 font-medium", children: "#10234987" })
                  ] }),
                  /* @__PURE__ */ jsxs("p", { class: "font-semibold text-base leading-7 text-black mt-4", children: [
                    "Order Payment : ",
                    /* @__PURE__ */ jsx("span", { class: "text-gray-400 font-medium", children: " 18th march 2021" })
                  ] })
                ] }),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    class: "rounded-full py-3 px-7 font-semibold text-sm leading-7 text-white bg-indigo-600 max-lg:mt-5 shadow-sm shadow-transparent transition-all duration-500 hover:bg-indigo-700 hover:shadow-indigo-400",
                    children: "Track Your Order"
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsxs("div", { class: "w-full px-3 min-[400px]:px-6", children: [
            /* @__PURE__ */ jsxs("div", { class: "flex flex-col lg:flex-row items-center py-6 border-b border-gray-200 gap-6 w-full", children: [
              /* @__PURE__ */ jsx("div", { class: "img-box max-lg:w-full", children: /* @__PURE__ */ jsx(
                "img",
                {
                  src: "https://pagedone.io/asset/uploads/1701167607.png",
                  alt: "Premium Watch image",
                  class: "aspect-square w-full lg:max-w-[140px] rounded-xl"
                }
              ) }),
              /* @__PURE__ */ jsx("div", { class: "flex flex-row items-center w-full ", children: /* @__PURE__ */ jsxs("div", { class: "grid grid-cols-1 lg:grid-cols-2 w-full", children: [
                /* @__PURE__ */ jsx("div", { class: "flex items-center", children: /* @__PURE__ */ jsxs("div", { class: "", children: [
                  /* @__PURE__ */ jsx("h2", { class: "font-semibold text-xl leading-8 text-black mb-3", children: "Premium Quality Dust Watch" }),
                  /* @__PURE__ */ jsx("p", { class: "font-normal text-lg leading-8 text-gray-500 mb-3 ", children: "By: Dust Studios" }),
                  /* @__PURE__ */ jsxs("div", { class: "flex items-center ", children: [
                    /* @__PURE__ */ jsxs(
                      "p",
                      {
                        class: "font-medium text-base leading-7 text-black pr-4 mr-4 border-r border-gray-200",
                        children: [
                          "Size: ",
                          /* @__PURE__ */ jsx("span", { class: "text-gray-500", children: "100 ml" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxs("p", { class: "font-medium text-base leading-7 text-black ", children: [
                      "Qty: ",
                      /* @__PURE__ */ jsx(
                        "span",
                        {
                          class: "text-gray-500",
                          children: "2"
                        }
                      )
                    ] })
                  ] })
                ] }) }),
                /* @__PURE__ */ jsxs("div", { class: "grid grid-cols-5", children: [
                  /* @__PURE__ */ jsx("div", { class: "col-span-5 lg:col-span-1 flex items-center max-lg:mt-3", children: /* @__PURE__ */ jsxs("div", { class: "flex gap-3 lg:block", children: [
                    /* @__PURE__ */ jsx("p", { class: "font-medium text-sm leading-7 text-black", children: "price" }),
                    /* @__PURE__ */ jsx("p", { class: "lg:mt-4 font-medium text-sm leading-7 text-indigo-600", children: "$100" })
                  ] }) }),
                  /* @__PURE__ */ jsx("div", { class: "col-span-5 lg:col-span-2 flex items-center max-lg:mt-3 ", children: /* @__PURE__ */ jsxs("div", { class: "flex gap-3 lg:block", children: [
                    /* @__PURE__ */ jsx("p", { class: "font-medium text-sm leading-7 text-black", children: "Status" }),
                    /* @__PURE__ */ jsx(
                      "p",
                      {
                        class: "font-medium text-sm leading-6 whitespace-nowrap py-0.5 px-3 rounded-full lg:mt-3 bg-emerald-50 text-emerald-600",
                        children: "Ready for Delivery"
                      }
                    )
                  ] }) }),
                  /* @__PURE__ */ jsx("div", { class: "col-span-5 lg:col-span-2 flex items-center max-lg:mt-3", children: /* @__PURE__ */ jsxs("div", { class: "flex gap-3 lg:block", children: [
                    /* @__PURE__ */ jsx("p", { class: "font-medium text-sm whitespace-nowrap leading-6 text-black", children: "Expected Delivery Time" }),
                    /* @__PURE__ */ jsx("p", { class: "font-medium text-base whitespace-nowrap leading-7 lg:mt-3 text-emerald-500", children: "23rd March 2021" })
                  ] }) })
                ] })
              ] }) })
            ] }),
            /* @__PURE__ */ jsxs("div", { class: "flex flex-col lg:flex-row items-center py-6 gap-6 w-full", children: [
              /* @__PURE__ */ jsx("div", { class: "img-box max-lg:w-full", children: /* @__PURE__ */ jsx(
                "img",
                {
                  src: "https://pagedone.io/asset/uploads/1701167621.png",
                  alt: "Diamond Watch image",
                  class: "aspect-square w-full lg:max-w-[140px] rounded-xl"
                }
              ) }),
              /* @__PURE__ */ jsx("div", { class: "flex flex-row items-center w-full ", children: /* @__PURE__ */ jsxs("div", { class: "grid grid-cols-1 lg:grid-cols-2 w-full", children: [
                /* @__PURE__ */ jsx("div", { class: "flex items-center", children: /* @__PURE__ */ jsxs("div", { class: "", children: [
                  /* @__PURE__ */ jsx("h2", { class: "font-semibold text-xl leading-8 text-black mb-3 ", children: "Diamond Platinum Watch" }),
                  /* @__PURE__ */ jsx("p", { class: "font-normal text-lg leading-8 text-gray-500 mb-3", children: "Diamond Dials" }),
                  /* @__PURE__ */ jsxs("div", { class: "flex items-center  ", children: [
                    /* @__PURE__ */ jsxs(
                      "p",
                      {
                        class: "font-medium text-base leading-7 text-black pr-4 mr-4 border-r border-gray-200",
                        children: [
                          "Size: ",
                          /* @__PURE__ */ jsx("span", { class: "text-gray-500", children: "Regular" })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxs("p", { class: "font-medium text-base leading-7 text-black ", children: [
                      "Qty: ",
                      /* @__PURE__ */ jsx(
                        "span",
                        {
                          class: "text-gray-500",
                          children: "1"
                        }
                      )
                    ] })
                  ] })
                ] }) }),
                /* @__PURE__ */ jsxs("div", { class: "grid grid-cols-5", children: [
                  /* @__PURE__ */ jsx("div", { class: "col-span-5 lg:col-span-1 flex items-center max-lg:mt-3", children: /* @__PURE__ */ jsxs("div", { class: "flex gap-3 lg:block", children: [
                    /* @__PURE__ */ jsx("p", { class: "font-medium text-sm leading-7 text-black", children: "price" }),
                    /* @__PURE__ */ jsx("p", { class: "lg:mt-4 font-medium text-sm leading-7 text-indigo-600", children: "$100" })
                  ] }) }),
                  /* @__PURE__ */ jsx("div", { class: "col-span-5 lg:col-span-2 flex items-center max-lg:mt-3 ", children: /* @__PURE__ */ jsxs("div", { class: "flex gap-3 lg:block", children: [
                    /* @__PURE__ */ jsx("p", { class: "font-medium text-sm leading-7 text-black", children: "Status" }),
                    /* @__PURE__ */ jsx(
                      "p",
                      {
                        class: "font-medium text-sm leading-6 py-0.5 px-3 whitespace-nowrap rounded-full lg:mt-3 bg-indigo-50 text-indigo-600",
                        children: "Dispatched"
                      }
                    )
                  ] }) }),
                  /* @__PURE__ */ jsx("div", { class: "col-span-5 lg:col-span-2 flex items-center max-lg:mt-3", children: /* @__PURE__ */ jsxs("div", { class: "flex gap-3 lg:block", children: [
                    /* @__PURE__ */ jsx("p", { class: "font-medium text-sm whitespace-nowrap leading-6 text-black", children: "Expected Delivery Time" }),
                    /* @__PURE__ */ jsx("p", { class: "font-medium text-base whitespace-nowrap leading-7 lg:mt-3 text-emerald-500", children: "23rd March 2021" })
                  ] }) })
                ] })
              ] }) })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { class: "w-full border-t border-gray-200 px-6 flex flex-col lg:flex-row items-center justify-between ", children: [
            /* @__PURE__ */ jsxs("div", { class: "flex flex-col sm:flex-row items-center max-lg:border-b border-gray-200", children: [
              /* @__PURE__ */ jsxs(
                "button",
                {
                  class: "flex outline-0 py-6 sm:pr-6  sm:border-r border-gray-200 whitespace-nowrap gap-2 items-center justify-center font-semibold group text-lg text-black bg-white transition-all duration-500 hover:text-indigo-600",
                  children: [
                    /* @__PURE__ */ jsx(
                      "svg",
                      {
                        class: "stroke-black transition-all duration-500 group-hover:stroke-indigo-600",
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "22",
                        height: "22",
                        viewBox: "0 0 22 22",
                        fill: "none",
                        children: /* @__PURE__ */ jsx(
                          "path",
                          {
                            d: "M5.5 5.5L16.5 16.5M16.5 5.5L5.5 16.5",
                            stroke: "",
                            "stroke-width": "1.6",
                            "stroke-linecap": "round"
                          }
                        )
                      }
                    ),
                    "Cancel Order"
                  ]
                }
              ),
              /* @__PURE__ */ jsxs("p", { class: "font-medium text-lg text-gray-900 pl-6 py-3 max-lg:text-center", children: [
                "Paid using Credit Card ",
                /* @__PURE__ */ jsx("span", { class: "text-gray-500", children: "ending with 8822" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("p", { class: "font-semibold text-lg text-black py-6", children: [
              "Total Price: ",
              /* @__PURE__ */ jsx("span", { class: "text-indigo-600", children: " $200.00" })
            ] })
          ] })
        ] })
      ] }) })
    }
  );
}
export {
  View as default
};
