import { jsxs, jsx } from "react/jsx-runtime";
import { useState, Fragment } from "react";
import { T as ThemeSwitcher, C as ClothingShopLogo, H as Harmbuger, N as NavLink } from "./Harmbuger-ZdqdIL5A.js";
import "@inertiajs/react";
function Guest({ children, auth = true, header }) {
  const [showingNavigationDropdown, setShowingNavigationDropdown] = useState(false);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      class: `relative min-h-screen ${auth && "flex flex-col justify-between pt-6 sm:pt-0"}`,
      children: [
        /* @__PURE__ */ jsx("nav", { class: "bg-white shadow-lg dark:bg-gray-950 py-3.5 px-6  w-full lg:shadow-none fixed z-50", children: /* @__PURE__ */ jsxs("div", { class: "flex items-center justify-between gap-1 sm:gap-6 lg:flex-row flex-col", children: [
          /* @__PURE__ */ jsxs("div", { class: "flex justify-between items-center lg:w-auto w-full", children: [
            /* @__PURE__ */ jsx(ThemeSwitcher, { className: "lg:hidden" }),
            /* @__PURE__ */ jsx("a", { href: "#", class: "block", children: /* @__PURE__ */ jsx(ClothingShopLogo, {}) }),
            /* @__PURE__ */ jsxs(
              "button",
              {
                id: "navbar-toggle",
                type: "button",
                class: "inline-flex items-center mr-3 text-sm rounded-lg lg:hidden focus:outline-none ",
                "aria-controls": "navbar-default",
                "aria-expanded": "false",
                onClick: () => setShowingNavigationDropdown(!showingNavigationDropdown),
                children: [
                  /* @__PURE__ */ jsx("span", { class: "sr-only", children: "Open main menu" }),
                  /* @__PURE__ */ jsx(Harmbuger, { checked: showingNavigationDropdown })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs(
            "div",
            {
              id: "mobile-navbar",
              class: `${!showingNavigationDropdown && "hidden"} lg:flex flex-row w-full flex-1`,
              children: [
                /* @__PURE__ */ jsxs("ul", { class: "text-center flex lg:flex-row flex-col lg:gap-2 xl:gap-4 gap-2 items-start lg:ml-auto", children: [
                  /* @__PURE__ */ jsx(NavLink, { route: route("home"), active: route().current("home"), children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Home" }) }),
                  /* @__PURE__ */ jsx(NavLink, { route: route("shop"), active: route().current("shop"), children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Shop" }) }),
                  /* @__PURE__ */ jsx(NavLink, { route: route("login"), active: route().current("login"), children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Login" }) }),
                  /* @__PURE__ */ jsx(
                    NavLink,
                    {
                      route: route("register"),
                      active: route().current("register"),
                      children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Register" })
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx("div", { class: "text-center lg:flex  items-center gap-1  sm:gap-4 lg:ml-auto", children: /* @__PURE__ */ jsx("div", { class: " flex items-center lg:justify-start justify-center gap-1 sm:gap-2", children: /* @__PURE__ */ jsx(ThemeSwitcher, { className: "hidden lg:inline-flex" }) }) })
              ]
            }
          )
        ] }) }),
        /* @__PURE__ */ jsxs("div", { class: "pt-[68px] bg-gray-200 text-gray-900 dark:text-gray-100 dark:bg-gray-900 flex-grow flex flex-col", children: [
          /* @__PURE__ */ jsx("div", { class: "py-3.5 lg:px-8 px-3 bg-gray-300 dark:bg-gray-800", children: /* @__PURE__ */ jsx("div", { class: "block max-lg:pl-6", children: /* @__PURE__ */ jsx("p", { class: "text-lg font-medium text-gray-900 dark:text-white", children: "Home" }) }) }),
          /* @__PURE__ */ jsx(
            "div",
            {
              class: `w-full p-8 flex-grow ${auth && "flex flex-col justify-center items-center"}`,
              children: auth ? /* @__PURE__ */ jsx("div", { className: "mx-auto max-w-2xl px-6 lg:px-8 rounded-2xl bg-primary shadow-xl", children }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                children,
                " "
              ] })
            }
          )
        ] })
      ]
    }
  );
}
export {
  Guest as G
};
