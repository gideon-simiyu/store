import { jsx, jsxs } from "react/jsx-runtime";
function Confirm({ auth, order }) {
  return /* @__PURE__ */ jsx("section", { className: "py-24 relative", children: /* @__PURE__ */ jsx("div", { className: "w-full max-w-7xl px-4 md:px-5 lg:px-5 mx-auto", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex-col justify-start items-center lg:gap-12 gap-8 inline-flex", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex-col justify-start items-center gap-3 flex", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-center text-gray-900 text-3xl font-bold font-manrope leading-normal", children: "John, Thank You for Your Order!" }),
      /* @__PURE__ */ jsx("p", { className: "max-w-xl text-center text-gray-500 text-lg font-normal leading-8", children: "Your order is in good hands! We'll notify you once it's en route. For now, here's a snapshot of your purchase" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "w-full flex-col justify-start items-center lg:gap-10 gap-8 flex", children: [
      /* @__PURE__ */ jsxs("div", { className: "w-full flex-col justify-start items-start gap-6 flex", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full flex-col justify-start items-start gap-5 flex", children: [
          /* @__PURE__ */ jsxs("div", { className: "w-full md:px-6 px-2 py-4 border-y border-gray-200 justify-between items-center inline-flex", children: [
            /* @__PURE__ */ jsx("h3", { className: "text-gray-900 text-xl font-medium leading-8", children: "Item" }),
            /* @__PURE__ */ jsx("h3", { className: "text-right text-gray-900 text-xl font-medium leading-8", children: "Total" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "w-full md:px-6 px-2 pb-5 justify-between items-center gap-8 inline-flex border-b border-gray-300", children: [
            /* @__PURE__ */ jsxs("div", { className: "justify-start items-center gap-6 flex md:pb-5", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  className: "",
                  src: "https://pagedone.io/asset/uploads/1717406948.png",
                  alt: "Simple Black T-shirt image"
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "flex-col justify-start items-start gap-1.5 inline-flex", children: [
                /* @__PURE__ */ jsx("h5", { className: "text-gray-900 text-lg font-semibold leading-relaxed", children: "Simple Black T-shirt" }),
                /* @__PURE__ */ jsx("h6", { className: "text-gray-500 text-base font-normal leading-relaxed", children: "QTY: 1" })
              ] })
            ] }),
            /* @__PURE__ */ jsx("h4", { className: "text-right text-gray-900 text-lg font-medium leading-relaxed", children: "$52.00" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "w-full md:px-5 px-2 pb-6 justify-between items-center gap-8 inline-flex border-b border-gray-300", children: [
            /* @__PURE__ */ jsxs("div", { className: "justify-start items-center gap-6 flex md:pb-6", children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  className: "",
                  src: "https://pagedone.io/asset/uploads/1717406998.png",
                  alt: "White Woolen Girl’s Top image"
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "flex-col justify-start items-start gap-1.5 inline-flex", children: [
                /* @__PURE__ */ jsx("h4", { className: "text-gray-900 text-xl font-medium leading-8", children: "White Woolen Girl’s Top" }),
                /* @__PURE__ */ jsx("h6", { className: "text-gray-500 text-base font-normal leading-relaxed", children: "QTY : 2" })
              ] })
            ] }),
            /* @__PURE__ */ jsx("h4", { className: "text-right text-gray-900 text-lg font-medium leading-relaxed", children: "$120.00" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full md:pt-6 justify-start items-center gap-5 flex md:flex-row flex-col", children: [
          /* @__PURE__ */ jsxs("div", { className: "w-full md:px-6 px-2 flex-col justify-start items-start gap-5 inline-flex md:border-r md:border-b-0 border-b md:pb-0 pb-5 border-gray-200", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full justify-between items-center inline-flex gap-4", children: [
              /* @__PURE__ */ jsx("h5", { className: "text-gray-500 text-lg font-normal leading-relaxed", children: "Estimated Delivery:" }),
              /* @__PURE__ */ jsx("h5", { className: "text-right text-gray-500 text-lg font-normal leading-relaxed", children: "Friday, 3rd Jun 2023" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full justify-between items-center inline-flex gap-4 border-y border-gray-200 py-5", children: [
              /* @__PURE__ */ jsx("h5", { className: "text-gray-500 text-lg font-normal leading-relaxed", children: "Delivery Address:" }),
              /* @__PURE__ */ jsx("h5", { className: "text-right text-gray-500 text-lg font-normal leading-relaxed", children: "123 Main Street Anytown, USA" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full justify-between items-center inline-flex gap-4", children: [
              /* @__PURE__ */ jsx("h5", { className: "text-gray-500 text-lg font-normal leading-relaxed", children: "Payment Method" }),
              /* @__PURE__ */ jsx("h5", { className: "text-right text-gray-500 text-lg font-normal leading-relaxed", children: "COD" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "w-full md:px-6 px-2 flex-col justify-start items-start gap-5 inline-flex", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full pb-6 border-b border-gray-200 flex-col justify-start items-start gap-6 flex", children: [
              /* @__PURE__ */ jsxs("div", { className: "w-full justify-between items-start gap-6 inline-flex", children: [
                /* @__PURE__ */ jsx("h5", { className: "text-gray-500 text-lg font-normal leading-relaxed", children: "Subtotal" }),
                /* @__PURE__ */ jsx("h5", { className: "text-right text-gray-900 text-lg font-semibold leading-relaxed", children: "$172.00" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full justify-between items-start gap-6 inline-flex", children: [
                /* @__PURE__ */ jsx("h5", { className: "text-gray-500 text-lg font-normal leading-relaxed", children: "Shipping" }),
                /* @__PURE__ */ jsx("h5", { className: "text-right text-gray-900 text-lg font-semibold leading-relaxed", children: "$20.00" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full justify-between items-start gap-6 inline-flex", children: [
              /* @__PURE__ */ jsx("h4", { className: "text-indigo-600 text-xl font-semibold leading-8", children: "Total" }),
              /* @__PURE__ */ jsx("h4", { className: "text-right text-indigo-600 text-xl font-semibold leading-8", children: "$192.00" })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "w-full justify-center items-center gap-8 flex sm:flex-row flex-col", children: [
        /* @__PURE__ */ jsx("button", { className: "md:w-fit w-full px-5 py-2.5 bg-indigo-50 hover:bg-indigo-100 transition-all duration-700 ease-in-out rounded-xl justify-center items-center flex", children: /* @__PURE__ */ jsx("span", { className: "px-2 py-px text-indigo-600 text-base font-semibold leading-relaxed", children: "Back to Shopping" }) }),
        /* @__PURE__ */ jsx("button", { className: "md:w-fit w-full px-5 py-2.5 bg-indigo-600 hover:bg-indigo-800 transition-all duration-700 ease-in-out rounded-xl shadow-[0px_1px_2px_0px_rgba(16,_24,_40,_0.05)] justify-center items-center flex", children: /* @__PURE__ */ jsx("span", { className: "px-2 py-px text-white text-base font-semibold leading-relaxed", children: "Track My Order" }) })
      ] })
    ] })
  ] }) }) });
}
export {
  Confirm as default
};
