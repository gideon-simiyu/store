import { jsxs, jsx } from "react/jsx-runtime";
import { P as ProductDisplay } from "./ProductDisplay-BxTQFFi7.js";
import { A as Authenticated } from "./AuthenticatedLayout-BEcBcb0X.js";
import { G as Guest } from "./GuestLayout-CKc0me1J.js";
import { Head } from "@inertiajs/react";
import { motion } from "framer-motion";
import "./Icons-XXBKsMCK.js";
import "@heroicons/react/20/solid";
import "react";
import "./Harmbuger-ZdqdIL5A.js";
function Home({ auth, products }) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };
  if (auth.user) {
    return /* @__PURE__ */ jsxs(
      Authenticated,
      {
        user: auth.user,
        header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight", children: "Home" }),
        children: [
          /* @__PURE__ */ jsx(Head, { title: "Home" }),
          /* @__PURE__ */ jsx(
            motion.div,
            {
              variants: containerVariants,
              initial: "hidden",
              animate: "visible",
              className: "flex flex-wrap justify-center",
              children: products.map((product) => {
                return /* @__PURE__ */ jsx(
                  motion.div,
                  {
                    variants: itemVariants,
                    className: "lg:basis-1/5 md:basis-1/3 sm:basis-1/2 basis-full p-6",
                    children: /* @__PURE__ */ jsx(ProductDisplay, { product })
                  },
                  product.id
                );
              })
            }
          )
        ]
      }
    );
  }
  return /* @__PURE__ */ jsxs(
    Guest,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight", children: "Home" }),
      auth: false,
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Home" }),
        /* @__PURE__ */ jsx(
          motion.div,
          {
            variants: containerVariants,
            initial: "hidden",
            animate: "visible",
            className: "flex flex-wrap justify-center",
            children: products.map((product) => {
              return /* @__PURE__ */ jsx(
                motion.div,
                {
                  variants: itemVariants,
                  className: "lg:basis-1/5 md:basis-1/3 sm:basis-1/2 basis-full px-10 md:p-6 lg:p-4 py-5",
                  children: /* @__PURE__ */ jsx(ProductDisplay, { product })
                },
                product.id
              );
            })
          }
        )
      ]
    }
  );
}
export {
  Home as default
};
