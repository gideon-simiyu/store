import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@inertiajs/react";
import { useState } from "react";
function DataTable({
  data,
  columns,
  headers,
  actions = false,
  className = "",
  image = null,
  view = false,
  remove = false,
  route = ""
}) {
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const filteredData = data.filter(
    (item) => columns.some((column) => {
      const columnValue = column.toString().includes(".") ? column.split(".").reduce((obj, i) => obj[i], item) : item[column.toLowerCase()];
      return columnValue.toString().toLowerCase().includes(searchTerm.toLowerCase());
    })
  );
  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  const paginatedData = filteredData.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );
  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };
  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };
  const handleRowsPerPageChange = (event) => {
    setRowsPerPage(Number(event.target.value));
    setCurrentPage(1);
  };
  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
    setCurrentPage(1);
  };
  const renderTable = () => /* @__PURE__ */ jsx("div", { className: "overflow-x-auto rounded-lg", children: /* @__PURE__ */ jsxs("table", { className: `w-full rounded-lg ${className}`, children: [
    /* @__PURE__ */ jsx("thead", { className: "border-b p-2 bg-indigo-500 text-white rounded-t-xl", children: /* @__PURE__ */ jsxs("tr", { children: [
      headers.map((header, index) => /* @__PURE__ */ jsx("th", { className: "text-left p-4 capitalize", children: header }, index)),
      actions && /* @__PURE__ */ jsx("th", { className: "text-left p-4", children: "Quick Actions" })
    ] }) }),
    /* @__PURE__ */ jsx("tbody", { children: paginatedData.map((item, rindex) => /* @__PURE__ */ jsxs(
      "tr",
      {
        className: `${rindex % 2 == 0 ? "dark:bg-slate-950 bg-gray-300" : "dark:bg-gray-900 bg-gray-400"} border-t border-gray-200 dark:border-slate-700 hover:bg-opacity-80`,
        children: [
          columns.map((column, index) => /* @__PURE__ */ jsx("td", { className: "p-4 text-nowrap", children: image && index == 0 ? /* @__PURE__ */ jsxs("div", { className: "flex", children: [
            /* @__PURE__ */ jsx(
              "img",
              {
                src: `/storage/${item[image]}`,
                alt: item[column.toLowerCase()],
                className: "w-10 h-10 rounded mr-2 object-cover bg-gray-300"
              }
            ),
            /* @__PURE__ */ jsx("span", { children: item[column.toLowerCase()] })
          ] }) : /* @__PURE__ */ jsx("span", { children: column.toString().includes(".") ? column.split(".").reduce((obj, i) => obj[i], item) : item[column.toLowerCase()] }) }, index)),
          actions && /* @__PURE__ */ jsx("td", { className: "p-4", children: /* @__PURE__ */ jsxs("div", { className: "flex", children: [
            view && /* @__PURE__ */ jsx(Link, { route: `${route}/${item.id}/view`, className: "mr-2 text-green-500", children: "view" }),
            remove && /* @__PURE__ */ jsx(Link, { route: `${route}/${item.id}/delete`, className: "ml-2 text-red-300", children: "delete" })
          ] }) })
        ]
      },
      item.id
    )) })
  ] }) });
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx("div", { className: "mb-4 flex justify-start", children: /* @__PURE__ */ jsx(
      "input",
      {
        type: "text",
        value: searchTerm,
        onChange: handleSearchChange,
        placeholder: "Search...",
        className: "px-4 py-2 border rounded w-full text-black dark:text-white bg-white dark:bg-gray-800 focus:ring-indigo-500 dark:focus:ring-indigo-600 focus:border-indigo-500 dark:focus:border-indigo-600"
      }
    ) }),
    renderTable(),
    /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center mt-4", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: handlePrevPage,
          disabled: currentPage === 1,
          className: "px-4 py-2 bg-gray-300 text-gray-700 rounded disabled:opacity-50",
          children: "Previous"
        }
      ),
      /* @__PURE__ */ jsxs("span", { className: "text-gray-700", children: [
        "Page ",
        currentPage,
        " of ",
        totalPages
      ] }),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: handleNextPage,
          disabled: currentPage === totalPages,
          className: "px-4 py-2 bg-gray-300 text-gray-700 rounded disabled:opacity-50",
          children: "Next"
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center ml-4", children: [
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "rowsPerPage",
            className: "mr-2 text-gray-700 dark:text-white",
            children: "Rows per page:"
          }
        ),
        /* @__PURE__ */ jsxs(
          "select",
          {
            id: "rowsPerPage",
            value: rowsPerPage,
            onChange: handleRowsPerPageChange,
            className: "px-2 py-1 border rounded w-full text-black dark:text-white bg-white dark:bg-gray-800",
            children: [
              /* @__PURE__ */ jsx("option", { value: 10, children: "10" }),
              /* @__PURE__ */ jsx("option", { value: 20, children: "20" }),
              /* @__PURE__ */ jsx("option", { value: 50, children: "50" }),
              /* @__PURE__ */ jsx("option", { value: 100, children: "100" })
            ]
          }
        )
      ] })
    ] })
  ] });
}
export {
  DataTable as D
};
