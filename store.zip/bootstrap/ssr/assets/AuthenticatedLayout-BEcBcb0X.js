import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { T as ThemeSwitcher, C as ClothingShopLogo, H as Harmbuger, N as NavLink } from "./Harmbuger-ZdqdIL5A.js";
import "@inertiajs/react";
function Authenticated({ user, header, children }) {
  const [showingNavigationDropdown, setShowingNavigationDropdown] = useState(false);
  return /* @__PURE__ */ jsxs("div", { class: "relative flex flex-col min-h-screen", children: [
    /* @__PURE__ */ jsx("nav", { class: "bg-white shadow-lg dark:bg-gray-950 py-3.5 px-6  w-full lg:shadow-none fixed z-50", children: /* @__PURE__ */ jsxs("div", { class: "flex items-center justify-between gap-1 sm:gap-6 lg:flex-row flex-col", children: [
      /* @__PURE__ */ jsxs("div", { class: "flex justify-between items-center lg:w-auto w-full", children: [
        /* @__PURE__ */ jsx(ThemeSwitcher, { className: "lg:hidden" }),
        /* @__PURE__ */ jsx("a", { href: "#", class: "block", children: /* @__PURE__ */ jsx(ClothingShopLogo, {}) }),
        /* @__PURE__ */ jsxs(
          "button",
          {
            id: "navbar-toggle",
            type: "button",
            class: "inline-flex items-center p-2 ml-3 text-sm  rounded-lg lg:hidden focus:outline-none ",
            "aria-controls": "navbar-default",
            "aria-expanded": "false",
            onClick: () => setShowingNavigationDropdown(!showingNavigationDropdown),
            children: [
              /* @__PURE__ */ jsx("span", { class: "sr-only", children: "Open main menu" }),
              /* @__PURE__ */ jsx(Harmbuger, { checked: showingNavigationDropdown })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxs(
        "div",
        {
          id: "mobile-navbar",
          class: `${!showingNavigationDropdown && "hidden"} lg:flex flex-row w-full flex-1`,
          children: [
            /* @__PURE__ */ jsxs("ul", { class: "text-center flex lg:flex-row flex-col lg:gap-2 xl:gap-4 gap-2 items-start lg:ml-auto", children: [
              /* @__PURE__ */ jsx(NavLink, { route: route("home"), active: route().current("home"), children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Home" }) }),
              /* @__PURE__ */ jsx(NavLink, { route: route("shop"), active: route().current("shop"), children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Shop" }) }),
              /* @__PURE__ */ jsx(NavLink, { route: route("cart"), active: route().current("cart"), children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Cart" }) }),
              /* @__PURE__ */ jsx(NavLink, { route: route("home"), active: route().current("orders"), children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Orders" }) }),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  route: route("profile.edit"),
                  active: route().current("profile.edit"),
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Profile" })
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  route: route("logout"),
                  active: route().current("logout"),
                  method: "post",
                  as: "button",
                  children: /* @__PURE__ */ jsx("span", { className: "ms-2", children: "Logout" })
                }
              )
            ] }),
            /* @__PURE__ */ jsx("div", { class: "text-center lg:flex  items-center gap-1  sm:gap-4 lg:ml-auto", children: /* @__PURE__ */ jsx("div", { class: " flex items-center lg:justify-start justify-center gap-1 sm:gap-2", children: /* @__PURE__ */ jsx(ThemeSwitcher, { className: "hidden lg:inline-flex" }) }) })
          ]
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxs("div", { class: "pt-[68px] flex-grow flex flex-col", children: [
      /* @__PURE__ */ jsx("div", { class: "py-3.5 lg:px-8 px-3 bg-gray-300 dark:bg-gray-800", children: /* @__PURE__ */ jsxs("div", { class: "block max-lg:pl-6", children: [
        /* @__PURE__ */ jsxs("h6", { class: "text-sm sm:text-lg font-semibold text-gray-900 dark:text-white whitespace-nowrap mb-1.5", children: [
          "Welcome back ,",
          /* @__PURE__ */ jsx("span", { class: "text-indigo-600 text-base sm:text-lg font-semibold px-2", children: user.name })
        ] }),
        /* @__PURE__ */ jsx("p", { class: "text-lg font-medium text-gray-900 dark:text-white", children: "Home" })
      ] }) }),
      /* @__PURE__ */ jsx("div", { class: "w-full flex-grow p-8 bg-gray-200 text-gray-900 dark:text-gray-100 dark:bg-gray-900", children })
    ] })
  ] });
}
export {
  Authenticated as A
};
