import { jsx } from "react/jsx-runtime";
import ReactDOMServer from "react-dom/server";
import { createInertiaApp } from "@inertiajs/react";
import createServer from "@inertiajs/react/server";
async function resolvePageComponent(path, pages) {
  for (const p of Array.isArray(path) ? path : [path]) {
    const page = pages[p];
    if (typeof page === "undefined") {
      continue;
    }
    return typeof page === "function" ? page() : page;
  }
  throw new Error(`Page not found: ${path}`);
}
const appName = "Laravel";
createServer(
  (page) => createInertiaApp({
    page,
    render: ReactDOMServer.renderToString,
    title: (title) => `${title} - ${appName}`,
    resolve: (name) => resolvePageComponent(`./Pages/${name}.jsx`, /* @__PURE__ */ Object.assign({ "./Pages/Auth/ConfirmPassword.jsx": () => import("./assets/ConfirmPassword-wA9TI_nA.js"), "./Pages/Auth/ForgotPassword.jsx": () => import("./assets/ForgotPassword-Dol77bAa.js"), "./Pages/Auth/Login.jsx": () => import("./assets/Login-HOSYeWI-.js"), "./Pages/Auth/Register.jsx": () => import("./assets/Register-atfyaIHv.js"), "./Pages/Auth/ResetPassword.jsx": () => import("./assets/ResetPassword-CnBWPYqr.js"), "./Pages/Auth/VerifyEmail.jsx": () => import("./assets/VerifyEmail-D1tGAsdt.js"), "./Pages/Cart.jsx": () => import("./assets/Cart-Dyh7SeM7.js"), "./Pages/Dashboard.jsx": () => import("./assets/Dashboard-CL7QkSu7.js"), "./Pages/Home.jsx": () => import("./assets/Home-KxV-qW7d.js"), "./Pages/Order/Confirm.jsx": () => import("./assets/Confirm-CAIhhtls.js"), "./Pages/Order/Track.jsx": () => import("./assets/Track-CVv_ZjrV.js"), "./Pages/Order/View.jsx": () => import("./assets/View-CuSW6ulh.js"), "./Pages/Product/Categories.jsx": () => import("./assets/Categories-DF0s1fjg.js"), "./Pages/Product/List.jsx": () => import("./assets/List-DQPEc8BO.js"), "./Pages/Product/Types.jsx": () => import("./assets/Types-Dluh8RrN.js"), "./Pages/Product/View.jsx": () => import("./assets/View-DbRKJ24S.js"), "./Pages/Profile/Edit.jsx": () => import("./assets/Edit-V3IkJBDT.js"), "./Pages/Profile/Partials/DeleteUserForm.jsx": () => import("./assets/DeleteUserForm-DTcdwl-y.js"), "./Pages/Profile/Partials/UpdatePasswordForm.jsx": () => import("./assets/UpdatePasswordForm-DiMEoolK.js"), "./Pages/Profile/Partials/UpdateProfileInformationForm.jsx": () => import("./assets/UpdateProfileInformationForm-BhZMbpLN.js"), "./Pages/Shop.jsx": () => import("./assets/Shop-nFUB8LJJ.js"), "./Pages/Welcome.jsx": () => import("./assets/Welcome-BoZdW6pG.js") })),
    setup: ({ App, props }) => {
      global.route = (name, params, absolute) => route(name, params, absolute, {
        ...page.props.ziggy,
        location: new URL(page.props.ziggy.location)
      });
      return /* @__PURE__ */ jsx(App, { ...props });
    }
  })
);
